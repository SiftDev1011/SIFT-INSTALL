/* Sift Discovery — the ONLY place you change web addresses.
 *
 * SIFT_MODE decides which pair of addresses the extension talks to:
 *   'live'  -> your real website and real backend (what customers use)
 *   'local' -> the copies running on your own computer (for testing)
 *
 * To test on your computer: change 'live' to 'local' below, then press the
 * little "reload" arrow on this extension's card at chrome://extensions.
 * Change it back to 'live' before you package the extension for customers.
 *
 * If your real domains are different from the ones below, edit them here
 * AND in manifest.json (the "host_permissions" and "externally_connectable"
 * lists) — Chrome needs to be told about every website the extension may talk to.
 */
const SIFT_MODE = 'live';

const SIFT_ADDRESSES = {
  live:  { SITE_BASE: 'https://sift.name.ng',  API_BASE: 'https://api.sift.name.ng' }, // website (accounts, ads)  /  backend (Discovery, checkout)
  local: { SITE_BASE: 'http://localhost:3000', API_BASE: 'http://localhost:3001' }
};

const SIFT = { MODE: SIFT_MODE, ...SIFT_ADDRESSES[SIFT_MODE] };
