/* Sift Discovery — background service worker
 *
 * Works exactly like Sift Extractor's, because it is the same Sift account:
 *  - SITE_BASE (sift-web) owns accounts, sign-in and the free-tier ads.
 *    "Do I have access?" is answered there.
 *  - API_BASE (sift-backend) owns checkout (Paddle), enterprise quotes and
 *    the Discovery searches themselves.
 *
 * No account = no use. With no session token the plan is 'signed_out' and the
 * popup sends people to the Sift website to sign in. One sign-in, one plan,
 * and one set of free ads unlock every Sift product.
 *
 * Extra for Discovery: a search keeps running on the server after the popup
 * closes, so this worker also watches the active search once a minute and
 * shows its progress on the toolbar icon.
 */

importScripts('config.js');

const { SITE_BASE, API_BASE } = SIFT;
const STATUS_TTL_MS = 45 * 1000;
const ALARM_NAME = 'sift-discovery-refresh';

let statusCache = null;
let inFlight = null;
let jobBadge = null; // { text, color } while a search is running or has just finished

/* ---------------- session token ----------------
 * Handed to us by sift-web after sign-in, via chrome.runtime.sendMessage —
 * see the onMessageExternal listener at the bottom of this file. It is the
 * same kind of token Sift Extractor receives. */

async function getSessionToken() {
  const { sessionToken } = await chrome.storage.local.get('sessionToken');
  return sessionToken || null;
}

async function setSession(token, email) {
  await chrome.storage.local.set({ sessionToken: token, userEmail: email || null });
}

async function clearSession() {
  await chrome.storage.local.remove(['sessionToken', 'userEmail', 'activeJobId', 'finishedJobId']);
  statusCache = null;
  jobBadge = null;
}

async function getUserEmail() {
  const { userEmail } = await chrome.storage.local.get('userEmail');
  return userEmail || null;
}

/* ---------------- status ----------------
 * plan is one of: 'signed_out' | 'free' | 'pro' | 'enterprise'. */

function signedOutStatus() {
  return { plan: 'signed_out', accessUntil: null, adsWatchedInCycle: 0, adsRequired: 5, now: Date.now(), fetchedAt: Date.now() };
}

function hasAccess(status) {
  if (!status) return false;
  if (status.plan === 'pro' || status.plan === 'enterprise') return true;
  if (status.plan === 'signed_out') return false;
  return Boolean(status.accessUntil && status.accessUntil > Date.now());
}

async function fetchStatus(force = false) {
  if (!force && statusCache && Date.now() - statusCache.fetchedAt < STATUS_TTL_MS) {
    return statusCache;
  }
  if (inFlight) return inFlight;

  inFlight = (async () => {
    const token = await getSessionToken();
    if (!token) {
      statusCache = signedOutStatus();
      updateBadge(statusCache);
      return statusCache;
    }

    try {
      const res = await fetch(`${SITE_BASE}/api/ads/session/status`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.status === 401) {
        // Token expired or revoked — same as never having signed in.
        await clearSession();
        statusCache = signedOutStatus();
      } else if (!res.ok) {
        throw new Error(`status ${res.status}`);
      } else {
        const data = await res.json();
        statusCache = { ...data, fetchedAt: Date.now(), offline: false };
      }
    } catch (err) {
      // Network blip — keep whatever we last knew rather than discarding it.
      statusCache = statusCache
        ? { ...statusCache, fetchedAt: Date.now(), offline: true }
        : { ...signedOutStatus(), offline: true };
    }
    updateBadge(statusCache);
    return statusCache;
  })();

  try {
    return await inFlight;
  } finally {
    inFlight = null;
  }
}

/* ---------------- toolbar badge ----------------
 * A search in progress (or just finished) wins; otherwise show the free
 * minutes left, or "!" if signed out. */

function updateBadge(status) {
  if (jobBadge) {
    chrome.action.setBadgeText({ text: jobBadge.text });
    chrome.action.setBadgeBackgroundColor({ color: jobBadge.color });
    return;
  }
  if (!status) return;
  if (status.plan === 'pro' || status.plan === 'enterprise') {
    chrome.action.setBadgeText({ text: '' });
    return;
  }
  if (status.plan === 'signed_out') {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#A1A1AA' });
    return;
  }
  if (status.accessUntil && status.accessUntil > Date.now()) {
    const mins = Math.max(1, Math.ceil((status.accessUntil - Date.now()) / 60000));
    chrome.action.setBadgeText({ text: String(mins) });
    chrome.action.setBadgeBackgroundColor({ color: '#E5484D' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

/* ---------------- search progress while the popup is closed ---------------- */

const FINISHED = ['completed', 'failed', 'cancelled'];

async function checkActiveJob() {
  const { activeJobId } = await chrome.storage.local.get('activeJobId');
  if (!activeJobId) return;

  const token = await getSessionToken();
  if (!token) return;

  try {
    const res = await fetch(`${API_BASE}/api/discover/jobs/${encodeURIComponent(activeJobId)}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.status === 401) { await clearSession(); updateBadge(signedOutStatus()); return; }
    if (res.status === 404) { await chrome.storage.local.remove('activeJobId'); jobBadge = null; updateBadge(statusCache); return; }
    if (!res.ok) return;

    const { job } = await res.json();
    if (FINISHED.includes(job.status)) {
      await chrome.storage.local.set({ finishedJobId: activeJobId });
      await chrome.storage.local.remove('activeJobId');
      jobBadge = { text: job.status === 'failed' ? '!' : '✓', color: job.status === 'failed' ? '#A1A1AA' : '#18181B' };
    } else {
      jobBadge = { text: String(job.matchesCount || 0), color: '#18181B' };
    }
    updateBadge(statusCache);
  } catch { /* offline — try again next minute */ }
}

/* ---------------- keep things honest while the popup is closed ---------------- */

chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== ALARM_NAME) return;
  fetchStatus(true).then(checkActiveJob);
});
chrome.runtime.onStartup.addListener(() => fetchStatus(true).then(checkActiveJob));
chrome.runtime.onInstalled.addListener(() => fetchStatus(true));

/* ---------------- popup -> background ---------------- */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handleMessage(msg).then(sendResponse);
  return true; // keep the channel open for the async response
});

async function handleMessage(msg) {
  switch (msg.type) {
    case 'GET_STATUS': {
      const status = await fetchStatus(msg.force);
      return { ok: true, status, hasAccess: hasAccess(status), email: await getUserEmail() };
    }

    // One action covers both "not signed in" and "signed in but this cycle's
    // ads aren't finished" — the website's /profile page works out which.
    case 'OPEN_PROFILE': {
      chrome.tabs.create({ url: `${SITE_BASE}/profile?ext=${chrome.runtime.id}` });
      return { ok: true };
    }

    case 'OPEN_CHECKOUT': {
      const email = await getUserEmail();
      chrome.tabs.create({
        url: `${API_BASE}/checkout?plan=${encodeURIComponent(msg.plan)}&email=${encodeURIComponent(email || '')}&ext=${chrome.runtime.id}`
      });
      return { ok: true };
    }

    case 'OPEN_ENTERPRISE': {
      chrome.tabs.create({ url: `${SITE_BASE}/enterprise?ext=${chrome.runtime.id}` });
      return { ok: true };
    }

    case 'OPEN_SITE': {
      chrome.tabs.create({ url: `${SITE_BASE}/${msg.path || ''}` });
      return { ok: true };
    }

    // The backend said 401: the token is no good any more.
    case 'SESSION_EXPIRED': {
      await clearSession();
      updateBadge(signedOutStatus());
      return { ok: true };
    }

    // The popup is open and showing the search, so the toolbar badge can step aside.
    case 'JOB_SEEN': {
      jobBadge = null;
      await chrome.storage.local.remove('finishedJobId');
      updateBadge(statusCache);
      return { ok: true };
    }

    default:
      return { ok: false, error: 'unknown message type: ' + msg.type };
  }
}

/* ---------------- website / backend -> background ----------------
 * Only works from origins listed in manifest.json's externally_connectable.
 *
 *  SIFT_SESSION    the website hands us a token right after sign-in.
 *  SIFT_SIGNED_OUT sent when the person signs out on the website, so we lock
 *                  again immediately instead of waiting for the cache to expire.
 *  SIFT_UNLOCKED   the checkout success page sends this once Paddle confirms payment.
 */

chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'SIFT_SESSION' && typeof msg.token === 'string' && msg.token) {
    (async () => {
      await setSession(msg.token, msg.email);
      const status = await fetchStatus(true);
      sendResponse({ ok: true, hasAccess: hasAccess(status) });
    })();
    return true;
  }

  if (msg && msg.type === 'SIFT_SIGNED_OUT') {
    clearSession().then(() => {
      updateBadge(signedOutStatus());
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg && msg.type === 'SIFT_UNLOCKED') {
    fetchStatus(true).then(status => sendResponse({ ok: true, hasAccess: hasAccess(status) }));
    return true;
  }

  sendResponse({ ok: false });
});
