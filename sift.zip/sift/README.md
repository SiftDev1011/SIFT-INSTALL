# Sift

A browser extension that pulls every phone number, email, link, price, date or custom-regex match off whatever page you're on — then lets you filter, jump to, copy, or export them.

## Install (30 seconds)

1. Unzip the folder somewhere permanent.
2. Go to `chrome://extensions`
3. Turn on **Developer mode** (top right)
4. Click **Load unpacked** → select the `sift` folder
5. Pin it to your toolbar

Works in Chrome, Edge, Brave, Arc, and any other Chromium browser.

## Find anything

**Any text** is a find-in-page that goes further than Ctrl+F:

- Every occurrence is listed, with surrounding context, and `‹ 3/47 ›` steps through them. The current match turns coral; the rest stay amber.
- It searches **inside iframes**, which Ctrl+F won't do.
- It reads `title`, `alt`, `aria-label` and `tel:` links, so it finds text that isn't rendered.
- Matches **span tags**. `<b>+234</b> <span>803 555</span> 0192` is one phone number, not three fragments — Ctrl+F handles this, naive extension scrapers don't.
- Combined with **Harvest ↓** it searches a whole infinite feed, not just what's loaded.
- Then you can export the lot to CSV, which no find bar does.

`Aa` toggles case sensitivity, `|ab|` restricts to whole words. Your query is escaped, so `price: $50 (final)` is searched literally — no regex knowledge needed. Want regex? That's a separate chip.

Keys: `Enter` searches, `Enter` again steps forward, `↑`/`↓` step either way, `Esc` closes.

## Two ways to scan

| | What it does | Use when |
|---|---|---|
| **Scan page** | Reads what's in the DOM right now | Normal pages |
| **Harvest ↓** | Auto-scrolls to the bottom, waits for each chunk to load, collects as it goes, then puts you back where you started | Infinite feeds, marketplaces, search results |
| **click more** (checkbox) | During Harvest, also clicks "Load more" buttons when scrolling stops producing anything | Shops that need a click, not a scroll |
| **live** (checkbox) | Keeps watching the page after a scan — new matches get added as you scroll yourself | Feeds you want to browse normally |

Close the popup and keep scrolling: live mode keeps running in the page. Reopen Sift and the count has gone up.

## The demo that sells it

1. Open a directory-style page — business listings, a marketplace, a conference speaker list.
2. Click Sift → **Phone numbers** → type `+234` in the "containing" box → **Scan page**.
3. You get every Nigerian number on the page, deduped, with the surrounding text so you know whose it is.
4. Click any result — the page scrolls to it and it flashes amber.
5. **Export CSV** → done.

For the version that gets applause: on an infinite-scroll listings page, hit **Harvest ↓** instead. Watch the counter climb and the position strip fill in as it walks the feed, then land back at the top with everything collected.

## What's actually clever in here

- **Custom Highlight API.** Matches are highlighted on the live page without touching the DOM — no wrapper `<span>`s, so nothing breaks on React sites that re-render.
- **Runs in every iframe.** Scans all frames and remembers which frame each result came from, so "jump to" works inside embedded content too.
- **Deep scan.** Also reads `tel:` links, `title`, `alt`, `aria-label` and hidden input values — catches numbers that are on the page but not visible as text.
- **Page-position strip.** The bar under the count is a map of where matches sit from top to bottom of the page. Tall bar = dense cluster. Nobody expects this and it reads instantly.
- **Smart dedupe.** `+234 803 555 0192` and `+2348035550192` collapse into one row with a `×2` counter, because phone matches are normalized to digits before comparison.
- **Loose-pattern guard.** The phone matcher rejects things like `2020 2021 2022` — a match needs a real separator or a 7-digit run.
- **Survives virtualised lists.** Feeds like React Window delete rows once they scroll off-screen. Sift keeps its own copy of every match, and if a row gets rebuilt it re-points "jump to" at the new node instead of the dead one.
- **Clicks "Load more" too.** When scrolling stops producing results, Harvest looks for a button matching load/show/see/view more, clicks it, and waits for content rather than a fixed delay. A button that matches the text but loads nothing is marked dead and never retried. Submit buttons and links that navigate are skipped, since either would destroy the script mid-run.
- **Harvest knows when to stop.** It watches page height and match count together, and quits after a few rounds of nothing new — no fixed scroll count, no infinite loop on feeds that never end.
- **Finds the real scroller.** Plenty of feeds scroll an inner `div` rather than the window; Sift picks the largest genuinely-scrollable element instead of assuming.
- **Keyboard shortcut.** `Alt+Shift+S`.
- **Flattened text index.** The page's text nodes are joined into one string with an offset map, so a match can start in one tag and end in another. A NUL is inserted at block boundaries — nothing in any pattern matches it — so a match can never bleed from one paragraph into the next.
- **Two record modes.** Extraction collapses duplicates into one row with a count; search lists every occurrence so you can step through them. Same store, one flag.
- **activeTab only.** No "read all your data on all websites" permission warning. It only ever touches the tab you clicked it on.

## Files

| File | Job |
|---|---|
| `manifest.json` | MV3 config, `activeTab` + `scripting` only |
| `popup.html` | UI and styles |
| `popup.js` | Presets, cross-frame scan orchestration, dedupe, export |
| `content.js` | TreeWalker over visible text, highlight + reveal |

## Tested

Five suites run against jsdom — 47 assertions:

| Suite | Covers |
|---|---|
| `test/feed.mjs` | live capture, virtualised row recycling, dedupe counts, bad regex |
| `test/harvest.mjs` | lazy-load walking, completion, scroll restore, termination |
| `test/split.mjs` | matches spanning tags, block-break isolation, case and whole-word |
| `test/loadmore.mjs` | button detection past decoys, dead-button retirement, opt-out |
| `test/popuplogic.mjs` | query escaping, boundary placement, preset switching |

`cd test && npm i jsdom && node feed.mjs` (and so on for the rest).

## Known limits

- **Numbered pagination** (1 2 3 … Next) isn't followed — each page is a separate URL and the content script dies on navigation. Use Sift Web for those.
- **Icon-only "load more" buttons** won't be found; detection is by label text.
- Search backends usually cap results server-side regardless of how far you scroll.

## Things to add if you have time

- Saved patterns, so people keep their own regex library
- "Open all matched links in tabs"
- Right-click a selection → make a regex from it

## One practical note

Bulk-collecting people's contact details is regulated in most places — GDPR in the EU, NDPR in Nigeria, CAN-SPAM in the US — and scraping at volume also violates a lot of sites' terms. Fine for research, personal lookups, and a demo. Worth knowing before anyone points it at a directory and mails the results.
