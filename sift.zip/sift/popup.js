const $ = sel => document.querySelector(sel);

const escapeRe = str => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const PRESETS = [
  {
    id: 'text',
    label: 'Any text',
    search: true          // free-text find-in-page, every occurrence listed
  },
  {
    id: 'phone',
    label: 'Phone numbers',
    source: '\\+?\\(?\\d{1,4}\\)?[-.\\s]?\\(?\\d{1,4}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{3,4}(?:[-.\\s]?\\d{1,4})?',
    flags: 'g',
    minDigits: 7,
    maxDigits: 15,
    mustMatch: '[+()\\-.]|\\d{7}',
    normalize: v => (v.trim().startsWith('+') ? '+' : '') + v.replace(/\D/g, '')
  },
  {
    id: 'email',
    label: 'Emails',
    source: '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}',
    flags: 'g',
    normalize: v => v.toLowerCase()
  },
  {
    id: 'url',
    label: 'Links',
    source: 'https?:\\/\\/[^\\s<>"\'()\\[\\]]+',
    flags: 'g'
  },
  {
    id: 'handle',
    label: '@handles',
    source: '(?<![\\w@/])@[A-Za-z0-9_]{2,30}\\b',
    flags: 'g',
    normalize: v => v.toLowerCase()
  },
  {
    id: 'price',
    label: 'Prices',
    source: '(?:[$£€₦¥₹]|USD|NGN|EUR|GBP|INR)\\s?\\d[\\d,]*(?:\\.\\d{1,2})?',
    flags: 'gi'
  },
  {
    id: 'date',
    label: 'Dates',
    source: '\\b(?:\\d{1,2}[\\/.-]\\d{1,2}[\\/.-]\\d{2,4}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\\.?\\s+\\d{1,2},?\\s+\\d{2,4})\\b',
    flags: 'gi'
  },
  { id: 'regex', label: 'Custom regex', custom: true }
];

let active = PRESETS[0];
let results = [];
let tabId = null;
let poller = null;

/* ---------------- presets ---------------- */

function renderPresets() {
  const wrap = $('#presets');
  wrap.innerHTML = '';
  for (const p of PRESETS) {
    const b = document.createElement('button');
    b.className = 'chip';
    b.textContent = p.label;
    b.setAttribute('aria-pressed', String(p.id === active.id));
    b.addEventListener('click', () => {
      active = p;
      showRows();
      renderPresets();
      if (p.custom) $('#regex').focus();
      else if (p.search) $('#query').focus();
    });
    wrap.appendChild(b);
  }
}

function pressed(sel) { return $(sel).getAttribute('aria-pressed') === 'true'; }

function showRows() {
  $('#regexRow').hidden = !active.custom;
  $('#queryRow').hidden = !active.search;
  // Searching wants every occurrence; extracting wants one row per value.
  $('#dedupe').checked = !active.search;
}

function buildSpec() {
  const base = {
    presetId: active.id,
    filter: $('#filter').value,
    includeAttrs: $('#attrs').checked,
    live: $('#live').checked,
    clickMore: $('#clickMore').checked
  };

  if (active.search) {
    const q = $('#query').value;
    if (!q.trim()) return null;
    let source = escapeRe(q);
    // Only apply word boundaries where the query actually ends in word characters.
    if (pressed('#wholeWord')) {
      if (/^\w/.test(q)) source = '(?<!\\w)' + source;
      if (/\w$/.test(q)) source = source + '(?!\\w)';
    }
    return {
      ...base,
      source,
      flags: pressed('#matchCase') ? 'g' : 'gi',
      matchCase: pressed('#matchCase'),
      wholeWord: pressed('#wholeWord'),
      query: q,
      eachOccurrence: true
    };
  }

  if (active.custom) {
    const src = $('#regex').value.trim();
    if (!src) return null;
    return { ...base, source: src, flags: 'gi' };
  }
  return {
    ...base,
    source: active.source,
    flags: active.flags,
    minDigits: active.minDigits,
    maxDigits: active.maxDigits,
    mustMatch: active.mustMatch
  };
}

/* ---------------- tab plumbing ---------------- */

async function ensureTab() {
  if (tabId !== null) return tabId;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab.id;
  return tabId;
}

async function inject() {
  await chrome.scripting.executeScript({
    target: { tabId: await ensureTab(), allFrames: true },
    files: ['content.js']
  });
}

function merge(injections) {
  const out = [];
  for (const inj of injections) {
    if (!inj.result || !inj.result.hits) continue;
    for (const h of inj.result.hits) out.push({ ...h, frameId: inj.frameId });
  }
  return out;
}

function blockedMessage(err) {
  const m = String((err && err.message) || err);
  if (/cannot be scripted|Cannot access|chrome:\/\/|extension/i.test(m)) {
    return 'Chrome blocks extensions here. Try a normal web page.';
  }
  return m.slice(0, 60);
}

/* ---------------- scan ---------------- */

async function scan() {
  if (!ensureAccess()) return;
  const spec = buildSpec();
  if (!spec) {
    ($('#' + (active.search ? 'query' : 'regex'))).classList.add('bad');
    setNote(active.search ? 'Type something to find.' : 'Type a regex first.');
    return;
  }
  $('#regex').classList.remove('bad');
  $('#query').classList.remove('bad');
  busy(true);
  setNote('scanning…');

  try {
    await inject();
    const injections = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: s => window.__sift.scan(s),
      args: [spec]
    });

    const bad = injections.find(i => i.result && i.result.error);
    if (bad) {
      $('#regex').classList.add('bad');
      setNote('Invalid regex: ' + bad.result.message.slice(0, 44));
      return;
    }

    results = postProcess(merge(injections));
    cursor = -1;
    $('#query').dataset.done = $('#query').value;
    render(spec.live ? 'live' : null);
  } catch (err) {
    results = [];
    render();
    setNote(blockedMessage(err));
  } finally {
    busy(false);
  }
}

/* ---------------- harvest ---------------- */

async function harvest() {
  if (!ensureAccess()) return;
  const spec = buildSpec();
  if (!spec) {
    ($('#' + (active.search ? 'query' : 'regex'))).classList.add('bad');
    setNote(active.search ? 'Type something to find.' : 'Type a regex first.');
    return;
  }
  busy(true);
  setNote('harvesting… keep this open');

  try {
    await inject();
    // Fire and forget — the loop lives in the page, so it survives the popup closing.
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      func: s => window.__sift.harvest(s),
      args: [spec]
    }).catch(() => {});

    startPolling();
  } catch (err) {
    setNote(blockedMessage(err));
    busy(false);
  }
}

function startPolling() {
  stopPolling();
  let ticks = 0;
  poller = setInterval(async () => {
    ticks++;
    try {
      const injections = await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        func: () => (window.__sift ? window.__sift.collect() : null)
      });
      results = postProcess(merge(injections));
      const still = injections.some(i => i.result && i.result.harvesting);
      render('harvest');
      sweep(still ? Math.min(0.95, ticks / 40) : 1);
      if (!still) {
        stopPolling();
        busy(false);
        const clicked = injections.reduce((n, i) => Math.max(n, (i.result && i.result.clicked) || 0), 0);
        setNote(`harvest complete — ${results.length} kept${clicked ? `, ${clicked} click${clicked === 1 ? '' : 's'}` : ''}`);
        setTimeout(() => sweep(0), 900);
      }
    } catch {
      stopPolling();
      busy(false);
    }
  }, 450);
}

function stopPolling() {
  if (poller) { clearInterval(poller); poller = null; }
}

function sweep(ratio) {
  const el = $('#sweep');
  if (ratio <= 0) { el.style.opacity = '0'; return; }
  el.style.opacity = '1';
  el.style.top = (ratio * 100) + '%';
}

function busy(state) {
  $('#go').disabled = state;
  $('#harvest').disabled = state;
}

/* ---------------- results ---------------- */

function postProcess(raw) {
  const filter = $('#filter').value.trim();
  const norm = active.normalize || (v => v.trim());
  let list = raw;

  if (filter) {
    const needle = filter.toLowerCase().replace(/\s/g, '');
    list = list.filter(h => {
      const a = h.text.toLowerCase().replace(/\s/g, '');
      const b = norm(h.text).toLowerCase().replace(/\s/g, '');
      return a.includes(needle) || b.includes(needle);
    });
  }

  if ($('#dedupe').checked) {
    const seen = new Map();
    for (const h of list) {
      const key = norm(h.text);
      if (seen.has(key)) seen.get(key).dupes += h.dupes || 1;
      else seen.set(key, { ...h, dupes: h.dupes || 1 });
    }
    list = [...seen.values()];
  }

  return list.sort((a, b) => a.position - b.position);
}

function setNote(text, live) {
  const n = $('#note');
  n.innerHTML = '';
  if (live) n.appendChild(Object.assign(document.createElement('span'), { className: 'live-dot' }));
  n.appendChild(document.createTextNode(text));
}

function render(mode) {
  const n = results.length;
  if (cursor >= n) cursor = -1;
  $('#count').innerHTML = `<b>${n}</b> found`;

  if (mode === 'harvest') setNote(`harvesting… ${n} so far`, true);
  else if (mode === 'live') setNote(n ? 'live — scroll to catch more' : 'live — nothing yet', true);
  else setNote(n ? 'click a result to jump to it' : 'nothing matched');

  // The ruler is vertical: each bucket is a horizontal tick whose length and
  // opacity encode how many matches sit at that depth of the page.
  const strip = $('#strip');
  [...strip.querySelectorAll('i')].forEach(el => el.remove());
  if (n) {
    const BUCKETS = 48;
    const counts = new Array(BUCKETS).fill(0);
    for (const h of results) counts[Math.min(BUCKETS - 1, Math.floor(h.position * BUCKETS))] += h.dupes;
    const peak = Math.max(...counts, 1);
    counts.forEach((c, i) => {
      if (!c) return;
      const tick = document.createElement('i');
      const strength = c / peak;
      tick.style.top = (i / BUCKETS * 100) + '%';
      tick.style.width = (8 + strength * 13) + 'px';
      tick.style.opacity = (0.35 + strength * 0.65).toFixed(2);
      strip.appendChild(tick);
    });
  }

  const list = $('#list');
  list.innerHTML = '';

  if (!n) {
    list.innerHTML = '<div class="empty"><b>No matches.</b>Clear the "containing" filter, or try Harvest ↓ if the page loads as you scroll.</div>';
    $('#copy').disabled = $('#csv').disabled = true;
    updateNav();
    return;
  }

  const frag = document.createDocumentFragment();
  for (const h of results) {
    const row = document.createElement('button');
    row.className = 'hit';

    const val = document.createElement('div');
    val.className = 'val';
    val.textContent = h.text;
    if (h.dupes > 1) {
      const d = document.createElement('span');
      d.className = 'dupes';
      d.textContent = `  ×${h.dupes}`;
      val.appendChild(d);
    }

    const ctx = document.createElement('div');
    ctx.className = 'ctx';
    if (h.kind !== 'text') {
      const src = document.createElement('span');
      src.className = 'src';
      src.textContent = h.kind + ' ';
      ctx.appendChild(src);
    }
    ctx.appendChild(document.createTextNode(`${h.before}${h.text}${h.after}`));

    row.append(val, ctx);
    row.addEventListener('click', () => { cursor = results.indexOf(h); jumpTo(h); });
    frag.appendChild(row);
  }
  list.appendChild(frag);
  $('#copy').disabled = $('#csv').disabled = false;
  updateNav();
}

let cursor = -1;

function updateNav() {
  const n = results.length;
  $('#prev').disabled = $('#next').disabled = n === 0;
  $('#pos').textContent = n === 0 ? '—' : (cursor < 0 ? `1/${n}` : `${cursor + 1}/${n}`);
  [...document.querySelectorAll('.hit')].forEach((el, i) => el.classList.toggle('current', i === cursor));
}

function step(delta) {
  if (!results.length) return;
  cursor = (cursor + delta + results.length) % results.length;
  const hit = results[cursor];
  updateNav();
  const row = document.querySelectorAll('.hit')[cursor];
  if (row) row.scrollIntoView({ block: 'nearest' });
  jumpTo(hit, { close: false });
}

async function jumpTo(hit, opts = {}) {
  const close = opts.close !== false;
  try {
    // Only one match should wear the "current" colour, across every frame.
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: () => window.__sift && window.__sift.clearFocus()
    }).catch(() => {});

    const [res] = await chrome.scripting.executeScript({
      target: { tabId, frameIds: [hit.frameId] },
      func: id => window.__sift.reveal(id),
      args: [hit.id]
    });
    if (res && res.result && res.result.ok) {
      if (close) window.close();
      else setNote(`showing ${cursor + 1} of ${results.length}`);
      return;
    }
    setNote(res && res.result && res.result.reason === 'recycled'
      ? "That row was recycled by the feed — value's still yours to copy."
      : "Couldn't jump. Scan again.");
  } catch {
    setNote("Couldn't jump — page changed. Scan again.");
  }
}

/* ---------------- export ---------------- */

function copyAll() {
  navigator.clipboard.writeText(results.map(h => h.text).join('\n')).then(() => {
    $('#copy').textContent = `Copied ${results.length}`;
    setTimeout(() => ($('#copy').textContent = 'Copy all'), 1400);
  });
}

function exportCsv() {
  const esc = v => `"${String(v).replace(/"/g, '""')}"`;
  const rows = [['value', 'occurrences', 'found_in', 'context']];
  for (const h of results) rows.push([h.text, h.dupes, h.kind, `${h.before}${h.text}${h.after}`].map(esc));
  const blob = new Blob([rows.map(r => r.join(',')).join('\n')], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `sift-${active.id}-${Date.now()}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

/* ---------------- access gate ----------------
 * background.js owns the network calls and the source of truth; this
 * popup only asks it for status and mirrors what comes back. `unlocked`
 * is what scan()/harvest() check before doing anything real — the gate
 * panel being visible is what stops a click reaching them in practice,
 * this is the defensive second check (e.g. a 20-minute window running
 * out while the popup happens to be open).
 *
 * Two different locked states now, not one: 'signed_out' (no account
 * connected yet) and 'free' without an active window (signed in, but
 * this cycle's ads aren't done). Same gate panel, different copy — both
 * send the person to the same place (sift-web's /profile), which is
 * where signing in AND watching ads both happen now. */

let unlocked = true;

function ensureAccess() {
  if (!unlocked) { openGate(); return false; }
  return true;
}

function openGate() { document.querySelector('.frame').classList.add('locked'); }
function closeGate() { document.querySelector('.frame').classList.remove('locked'); }

function renderGateCopy(status) {
  const copy = $('#gateCopy');
  const action = $('#gateAction');
  if (status.plan === 'signed_out') {
    copy.textContent = 'Sign in to use Sift — free accounts get 20 minutes after a few short ads.';
    action.textContent = 'Sign in';
  } else {
    copy.textContent = `Finish this cycle's ads to keep going (${status.adsWatchedInCycle || 0} of ${status.adsRequired || 5} watched).`;
    action.textContent = 'Finish on your profile';
  }
}

function renderFreeBadge(status) {
  const badge = $('#freeBadge');
  if (status.plan !== 'free' || !status.accessUntil || status.accessUntil <= Date.now()) {
    badge.hidden = true;
    return;
  }
  const mins = Math.max(0, Math.ceil((status.accessUntil - Date.now()) / 60000));
  badge.hidden = false;
  badge.textContent = `free access · ${mins} min left`;
}

async function refreshAccess(force) {
  const res = await chrome.runtime.sendMessage({ type: 'GET_STATUS', force: !!force });
  if (!res || !res.ok) return;
  unlocked = res.hasAccess;
  renderFreeBadge(res.status);
  if (unlocked) {
    closeGate();
  } else {
    openGate();
    renderGateCopy(res.status);
  }
}

$('#gateAction').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_PROFILE' }));
$('#planMonthly').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_CHECKOUT', plan: 'monthly' }));
$('#planYearly').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_CHECKOUT', plan: 'yearly' }));
$('#gateEnterprise').addEventListener('click', e => { e.preventDefault(); chrome.runtime.sendMessage({ type: 'OPEN_ENTERPRISE' }); });

// Whoever grants access (sift-web's profile page, checkout) lives in a
// different tab, so re-check the moment this popup regains focus rather
// than waiting on the 1-minute alarm.
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) refreshAccess(true);
});

/* ---------------- restore on reopen ---------------- */

async function boot() {
  renderPresets();
  try {
    await inject();
    const injections = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: () => (window.__sift ? window.__sift.collect() : null)
    });

    const prior = injections.find(i => i.result && i.result.spec);
    if (prior) {
      const s = prior.result.spec;
      const found = PRESETS.find(p => p.id === s.presetId);
      if (found) { active = found; renderPresets(); }
      if (found && found.custom) $('#regex').value = s.source || '';
      if (found && found.search) {
        $('#query').value = s.query || '';
        $('#matchCase').setAttribute('aria-pressed', String(!!s.matchCase));
        $('#wholeWord').setAttribute('aria-pressed', String(!!s.wholeWord));
      }
      showRows();
      $('#filter').value = s.filter || '';
      $('#attrs').checked = !!s.includeAttrs;
      if (s.clickMore !== undefined) $('#clickMore').checked = !!s.clickMore;
      $('#live').checked = !!prior.result.live;
    }

    const harvesting = injections.some(i => i.result && i.result.harvesting);
    const hits = merge(injections);
    if (hits.length || harvesting) {
      results = postProcess(hits);
      render(harvesting ? 'harvest' : (prior && prior.result.live ? 'live' : null));
      if (harvesting) { busy(true); startPolling(); }
    }
  } catch { /* fresh page or restricted — leave the empty state up */ }
}

$('#go').addEventListener('click', scan);
$('#harvest').addEventListener('click', harvest);
$('#copy').addEventListener('click', copyAll);
$('#csv').addEventListener('click', exportCsv);
$('#live').addEventListener('change', e => {
  if (!e.target.checked) {
    chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: () => window.__sift && window.__sift.stopLive()
    }).catch(() => {});
  }
});
$('#prev').addEventListener('click', () => step(-1));
$('#next').addEventListener('click', () => step(1));

for (const id of ['#matchCase', '#wholeWord']) {
  $(id).addEventListener('click', () => {
    const el = $(id);
    el.setAttribute('aria-pressed', String(el.getAttribute('aria-pressed') !== 'true'));
    if (active.search && $('#query').value.trim()) scan();
  });
}

for (const id of ['#filter', '#regex', '#query']) {
  $(id).addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    // Enter searches; Enter again walks the results, like find-in-page.
    if (active.search && results.length && e.target.id === 'query' && !e.shiftKey && $('#query').dataset.done === $('#query').value) {
      step(1);
    } else {
      scan();
    }
  });
}

document.addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' && e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
  if (e.key === 'ArrowDown') { e.preventDefault(); step(1); }
  if (e.key === 'ArrowUp') { e.preventDefault(); step(-1); }
  if (e.key === 'Escape') window.close();
});
window.addEventListener('unload', stopPolling);

showRows();
$('#filter').focus();
refreshAccess();
boot();
