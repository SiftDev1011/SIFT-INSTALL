/* Sift — injected on demand. Defines window.__sift once per frame. */
(() => {
  if (window.__sift) return;

  const MAX_STORE = 6000;
  const MAX_RANGES = 2500;
  const CONTEXT = 42;
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'SVG']);
  const ATTR_TARGETS = [
    ['a[href]', 'href'],
    ['[title]', 'title'],
    ['img[alt]', 'alt'],
    ['[aria-label]', 'aria-label'],
    ['input[value]', 'value'],
    ['[data-phone]', 'data-phone']
  ];

  let store = new Map();   // key -> hit record
  let index = [];          // id -> { range } | { el }
  let ranges = [];         // live ranges for highlighting
  let guard = null;
  let spec = null;
  let observer = null;
  let queue = [];
  let pending = null;
  let harvesting = false;
  let seq = 0;
  let clicks = 0;
  const deadButtons = new WeakSet();

  /* ---------------- setup ---------------- */

  function ensureStyle() {
    if (document.getElementById('sift-style')) return;
    const s = document.createElement('style');
    s.id = 'sift-style';
    s.textContent = `
      ::highlight(sift) { background: #F5B942; color: #0E1F27; }
      ::highlight(sift-now) { background: #E8705F; color: #FFF; }
      .sift-pulse {
        position: absolute; z-index: 2147483647; pointer-events: none;
        border: 2px solid #F5B942; border-radius: 3px;
        box-shadow: 0 0 0 6px rgba(245,185,66,.28);
        animation: sift-fade 1.1s ease-out forwards;
      }
      @keyframes sift-fade { to { opacity: 0; transform: scale(1.06); } }
      @media (prefers-reduced-motion: reduce) { .sift-pulse { animation: sift-fade 1.1s linear forwards; } }
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  const isVisible = el => !el ? false
    : el.checkVisibility ? el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })
    : !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

  const digitsOf = s => (s.match(/\d/g) || []).length;

  function passes(text) {
    if (spec.minDigits && digitsOf(text) < spec.minDigits) return false;
    if (spec.maxDigits && digitsOf(text) > spec.maxDigits) return false;
    if (guard && !guard.test(text)) return false;
    return true;
  }

  function contextOf(hay, start, end) {
    const from = Math.max(0, start - CONTEXT);
    const to = Math.min(hay.length, end + CONTEXT);
    return {
      before: (from > 0 ? '…' : '') + hay.slice(from, start).replace(/[\s\u0000]+/g, ' '),
      after: hay.slice(end, to).replace(/[\s\u0000]+/g, ' ') + (to < hay.length ? '…' : '')
    };
  }

  function compile(next) {
    spec = next;
    guard = null;
    if (spec.mustMatch) { try { guard = new RegExp(spec.mustMatch); } catch { guard = null; } }
    try {
      const f = spec.flags.includes('g') ? spec.flags : spec.flags + 'g';
      return new RegExp(spec.source, f);
    } catch (err) {
      return { error: String(err.message || err) };
    }
  }

  /* ---------------- recording ---------------- */

  function record(text, kind, payload, ctx, top) {
    // Find-in-page wants every hit listed so you can step through them.
    // Extraction wants one row per distinct value, with a count.
    const key = spec.eachOccurrence
      ? kind + '\u0000' + text + '\u0000#' + (seq++)
      : kind + '\u0000' + text;
    const seen = store.get(key);

    if (seen) {
      seen.dupes++;
      // Virtualised feeds destroy and rebuild rows — keep whichever anchor is still live.
      const anchor = index[seen.id];
      const stale = anchor && anchor.range
        ? !anchor.range.startContainer.isConnected
        : anchor && anchor.el ? !anchor.el.isConnected : true;
      if (stale) {
        index[seen.id] = payload;
        seen.top = top;
      }
      return;
    }

    if (store.size >= MAX_STORE) return;
    index.push(payload);
    store.set(key, {
      id: index.length - 1,
      text, kind, top,
      dupes: 1,
      before: ctx.before,
      after: ctx.after
    });
  }

  // Text nodes are joined into a single string so a match can run across tags:
  // <b>+234</b> <span>803 555 0192</span> is one number, not three fragments.
  // A NUL is inserted at block boundaries — no pattern here matches it, so
  // matches can never bleed from one paragraph into the next.
  const BREAK = '\u0000';

  const INLINE_TAGS = new Set([
    'A','ABBR','B','BDI','BDO','BR','CITE','CODE','DEL','EM','FONT','I','INS','KBD',
    'LABEL','MARK','NOBR','Q','S','SAMP','SMALL','SPAN','STRONG','SUB','SUP','TIME',
    'U','VAR','WBR'
  ]);

  function isBlock(el, cache) {
    if (cache.has(el)) return cache.get(el);
    let block;
    if (INLINE_TAGS.has(el.tagName)) {
      block = false;
    } else {
      block = true;
      try {
        const d = getComputedStyle(el).display;
        if (d === 'inline' || d === 'contents' || d === 'inline-block') block = false;
      } catch { /* detached — assume block */ }
    }
    cache.set(el, block);
    return block;
  }

  function flatten(root) {
    const segs = [];
    let text = '';

    if (root.nodeType === Node.TEXT_NODE) {
      segs.push({ node: root, start: 0, end: root.nodeValue.length });
      return { text: root.nodeValue, segs };
    }

    const cache = new Map();

    // The break belongs at the nearest *block* ancestor, not the immediate parent —
    // coming back out of a <span> into the same <p> is not a new paragraph.
    const blockOf = el => {
      let cur = el;
      while (cur && !isBlock(cur, cache)) cur = cur.parentElement;
      return cur || root;
    };

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentElement;
        if (!p || SKIP_TAGS.has(p.tagName)) return NodeFilter.FILTER_REJECT;
        if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
        // Whitespace-only nodes carry no matches but do separate words — keep them.
        if (!isVisible(p)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    let node, prevBlock = null;
    while ((node = walker.nextNode())) {
      const block = blockOf(node.parentElement);
      if (prevBlock && block !== prevBlock) text += BREAK;
      const start = text.length;
      text += node.nodeValue;
      segs.push({ node, start, end: text.length });
      prevBlock = block;
    }
    return { text, segs };
  }

  function locate(segs, idx) {
    let lo = 0, hi = segs.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (idx < segs[mid].start) hi = mid - 1;
      else if (idx >= segs[mid].end) lo = mid + 1;
      else return segs[mid];
    }
    return null;
  }

  function scanRoot(root, re) {
    if (!root || !root.isConnected) return;

    const { text, segs } = flatten(root);
    if (segs.length) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(text)) !== null) {
        if (m[0] === '') { re.lastIndex++; continue; }
        if (m[0].includes(BREAK)) continue;
        if (!passes(m[0])) continue;

        const s0 = locate(segs, m.index);
        const s1 = locate(segs, m.index + m[0].length - 1);
        if (!s0 || !s1) continue;

        const range = document.createRange();
        try {
          range.setStart(s0.node, m.index - s0.start);
          range.setEnd(s1.node, m.index + m[0].length - s1.start);
        } catch { continue; }

        const top = range.getBoundingClientRect().top + window.scrollY;
        const ctx = contextOf(text, m.index, m.index + m[0].length);
        record(m[0].trim(), 'text', { range }, ctx, top);
        if (ranges.length < MAX_RANGES) ranges.push(range);
      }
    }

    if (spec.includeAttrs && root.nodeType === Node.ELEMENT_NODE) {
      for (const [sel, attr] of ATTR_TARGETS) {
        let els;
        try {
          els = [...root.querySelectorAll(sel)];
          if (root.matches && root.matches(sel)) els.push(root);
        } catch { continue; }

        for (const el of els) {
          const value = attr === 'value' ? el.value : el.getAttribute(attr);
          if (!value) continue;
          re.lastIndex = 0;
          let m;
          const here = new Set();
          while ((m = re.exec(value)) !== null) {
            if (m[0] === '') { re.lastIndex++; continue; }
            if (!passes(m[0]) || here.has(m[0])) continue;
            here.add(m[0]);
            const top = el.getBoundingClientRect().top + window.scrollY;
            record(decodeURIComponent(m[0]).trim(), attr, { el }, { before: attr + '="', after: '"' }, top);
          }
        }
      }
    }

    paint();
  }

  function paint() {
    if (!(window.CSS && window.CSS.highlights && window.Highlight)) return;
    const live = ranges.filter(r => r.startContainer.isConnected);
    if (live.length !== ranges.length) ranges = live;
    try { window.CSS.highlights.set('sift', new window.Highlight(...live)); } catch { /* no-op */ }
  }

  function snapshot() {
    const docHeight = Math.max(
      document.documentElement.scrollHeight,
      document.body ? document.body.scrollHeight : 0, 1
    );
    return [...store.values()].map(h => ({
      id: h.id, text: h.text, kind: h.kind, dupes: h.dupes,
      before: h.before, after: h.after,
      position: Math.min(1, Math.max(0, h.top / docHeight))
    }));
  }

  /* ---------------- live mode ---------------- */

  function digest(records) {
    const re = compile(spec);
    if (re.error) return;
    const roots = new Set();
    for (const r of records) {
      if (r.type === 'characterData') { roots.add(r.target); continue; }
      for (const n of r.addedNodes) {
        if (n.nodeType === Node.ELEMENT_NODE || n.nodeType === Node.TEXT_NODE) roots.add(n);
      }
    }
    for (const root of roots) scanRoot(root, re);
  }

  // The observer callback empties its own record queue when it runs, so records
  // must be buffered here — takeRecords() alone would come back empty.
  function drain() {
    if (observer) queue.push(...observer.takeRecords());
    if (!queue.length) return;
    const records = queue;
    queue = [];
    digest(records);
  }

  function startLive() {
    if (observer) return;
    observer = new MutationObserver(records => {
      if (queue.length < 20000) queue.push(...records);
      if (harvesting) return;            // harvest drains on its own schedule
      if (pending) clearTimeout(pending);
      pending = setTimeout(() => { pending = null; drain(); }, 180);
    });
    observer.observe(document.body || document.documentElement, {
      childList: true, subtree: true, characterData: true
    });
  }

  function stopLive() {
    if (observer) { observer.disconnect(); observer = null; }
    if (pending) { clearTimeout(pending); pending = null; }
    queue = [];
  }

  /* ---------------- harvest ---------------- */

  const wait = ms => new Promise(r => setTimeout(r, ms));

  // Feeds often scroll an inner div rather than the window.
  function pickScroller() {
    const doc = document.scrollingElement || document.documentElement;
    if (doc.scrollHeight > window.innerHeight + 40) return doc;
    let best = null, bestArea = 0;
    for (const el of document.querySelectorAll('div, main, section, ul')) {
      if (el.scrollHeight <= el.clientHeight + 120) continue;
      const ov = getComputedStyle(el).overflowY;
      if (ov !== 'auto' && ov !== 'scroll') continue;
      const r = el.getBoundingClientRect();
      const area = r.width * r.height;
      if (area > bestArea) { best = el; bestArea = area; }
    }
    return best || doc;
  }

  const MORE_RE = /(?:load|show|see|view|fetch)\s+(?:more|next|older|additional)|load\s*more|show\s*more|^\s*more\s*$/i;
  const NOT_MORE_RE = /less|filter|option|detail|comment|repl(?:y|ies)|sign|log\s*in|cart|checkout|subscribe/i;
  const CLICKABLE = 'button, [role="button"], a, input[type="button"], input[type="submit"]';

  function findLoadMore() {
    let best = null, bestTop = -Infinity;

    for (const el of document.querySelectorAll(CLICKABLE)) {
      if (deadButtons.has(el) || el.disabled) continue;

      const label = (el.innerText ?? el.textContent ?? el.value ?? el.getAttribute('aria-label') ?? '').trim();
      if (!label || label.length > 40) continue;
      if (!MORE_RE.test(label) || NOT_MORE_RE.test(label)) continue;
      if (!isVisible(el)) continue;

      // A submit button reloads the page and kills this script — leave it alone.
      if (el.form && (el.type === 'submit' || el.tagName === 'INPUT')) continue;

      // Same for a link that actually navigates somewhere else.
      if (el.tagName === 'A') {
        const href = el.getAttribute('href') || '';
        if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
          try {
            const to = new URL(href, location.href);
            if (to.pathname !== location.pathname || to.search !== location.search) continue;
          } catch { continue; }
        }
      }

      // Prefer the lowest candidate — the real one sits at the end of the list.
      const top = el.getBoundingClientRect().top + window.scrollY;
      if (top > bestTop) { best = el; bestTop = top; }
    }
    return best;
  }

  async function clickLoadMore(maxWaitMs = 4000) {
    const btn = findLoadMore();
    if (!btn) return false;

    const beforeH = document.documentElement.scrollHeight;
    const beforeN = store.size;

    try {
      btn.scrollIntoView({ block: 'center' });
      btn.click();
    } catch { deadButtons.add(btn); return false; }
    clicks++;

    // Wait for the content, not for a fixed guess at how slow the network is.
    const step = 200;
    for (let waited = 0; waited < maxWaitMs; waited += step) {
      await wait(step);
      drain();
      if (document.documentElement.scrollHeight > beforeH || store.size > beforeN) return true;
    }

    // Matched the text but loaded nothing — never try this one again.
    deadButtons.add(btn);
    return false;
  }

  async function harvest(next, opts = {}) {
    const re = compile(next);
    if (re.error) return { error: 'bad-pattern', message: re.error };

    reset();
    ensureStyle();
    startLive();
    harvesting = true;

    const maxSteps = opts.maxSteps || 60;
    const settle = opts.settle || 700;
    const scroller = pickScroller();
    const isDoc = scroller === (document.scrollingElement || document.documentElement);
    const startY = isDoc ? window.scrollY : scroller.scrollTop;

    scanRoot(document.body, re);

    let stagnant = 0;
    for (let step = 0; step < maxSteps; step++) {
      const beforeH = scroller.scrollHeight;
      const beforeN = store.size;

      const jump = (isDoc ? window.innerHeight : scroller.clientHeight) * 0.9;
      if (isDoc) window.scrollBy(0, jump);
      else scroller.scrollTop += jump;

      await wait(settle);
      drain();

      const atEnd = isDoc
        ? window.scrollY + window.innerHeight >= scroller.scrollHeight - 4
        : scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;

      const grew = scroller.scrollHeight > beforeH || store.size > beforeN;
      stagnant = grew ? 0 : stagnant + 1;

      // Scrolling stopped working. Before giving up, look for a "Load more" button —
      // plenty of feeds need a click rather than a scroll.
      if (!grew && next.clickMore !== false && clicks < (opts.maxClicks || 50)) {
        if (await clickLoadMore(opts.clickWaitMs || 4000)) { stagnant = 0; continue; }
      }

      // Bottom reached and nothing new arriving after a few tries — the feed is done.
      if (atEnd && stagnant >= 3) break;
      if (stagnant >= 6) break;
    }

    harvesting = false;
    drain();
    const clicked = clicks;

    if (opts.restore !== false) {
      if (isDoc) window.scrollTo({ top: startY, behavior: 'auto' });
      else scroller.scrollTop = startY;
    }
    return { hits: snapshot(), done: true, clicked };
  }

  /* ---------------- entry points ---------------- */

  function reset() {
    store = new Map();
    index = [];
    ranges = [];
    queue = [];
    seq = 0;
    clicks = 0;
    if (window.CSS && window.CSS.highlights) {
      window.CSS.highlights.delete('sift');
      window.CSS.highlights.delete('sift-now');
    }
    document.querySelectorAll('.sift-pulse').forEach(n => n.remove());
  }

  function scan(next) {
    const re = compile(next);
    if (re.error) return { error: 'bad-pattern', message: re.error };
    reset();
    ensureStyle();
    scanRoot(document.body || document.documentElement, re);
    if (next.live) startLive(); else stopLive();
    return { hits: snapshot() };
  }

  // Called when the popup reopens — returns whatever has accumulated meanwhile.
  function collect() {
    if (pending) { clearTimeout(pending); pending = null; }
    drain();
    return { hits: snapshot(), live: !!observer, harvesting, spec, clicked: clicks };
  }

  function reveal(id) {
    const entry = index[id];
    if (!entry) return { ok: false, reason: 'gone' };

    const node = entry.range ? entry.range.startContainer : entry.el;
    if (!node || !node.isConnected) return { ok: false, reason: 'recycled' };

    if (entry.range && window.CSS && window.CSS.highlights && window.Highlight) {
      try { window.CSS.highlights.set('sift-now', new window.Highlight(entry.range)); } catch { /* no-op */ }
    }

    const target = entry.range ? entry.range.startContainer.parentElement : entry.el;
    if (target) target.scrollIntoView({ block: 'center', behavior: 'smooth' });

    setTimeout(() => {
      const r = entry.range ? entry.range.getBoundingClientRect() : entry.el.getBoundingClientRect();
      const pulse = document.createElement('div');
      pulse.className = 'sift-pulse';
      pulse.style.left = (r.left + window.scrollX - 3) + 'px';
      pulse.style.top = (r.top + window.scrollY - 3) + 'px';
      pulse.style.width = (r.width + 6) + 'px';
      pulse.style.height = (r.height + 6) + 'px';
      document.body.appendChild(pulse);
      setTimeout(() => pulse.remove(), 1200);
    }, 320);

    return { ok: true };
  }

  function clearFocus() {
    if (window.CSS && window.CSS.highlights) window.CSS.highlights.delete('sift-now');
  }

  function clear() { stopLive(); reset(); }

  window.__sift = { scan, collect, harvest, reveal, clear, stopLive, clearFocus };
})();
