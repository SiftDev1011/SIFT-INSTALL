import { JSDOM } from 'jsdom';
import fs from 'fs';

const html = `<!doctype html><html><body>
  <p id="a">Call <b>+234</b> <span>803 555</span> 0192 now</p>
  <p id="b">Ends here</p><p id="c">7778889999 starts</p>
  <div id="d">the quick <em>brown</em> fox jumps</div>
  <div id="e">THE QUICK brown fox</div>
  <p id="f">brownstone building</p>
</body></html>`;

const dom = new JSDOM(html, { url: 'https://example.com', pretendToBeVisual: true });
const { window } = dom; const { document } = window;
window.Element.prototype.checkVisibility = () => true;
window.Range.prototype.getBoundingClientRect = () => ({ top: 0, left: 0, width: 10, height: 10 });
window.Element.prototype.getBoundingClientRect = () => ({ top: 0, left: 0, width: 10, height: 10 });
window.Element.prototype.scrollIntoView = function () {};

globalThis.window = window; globalThis.document = document;
globalThis.Node = window.Node; globalThis.NodeFilter = window.NodeFilter;
globalThis.MutationObserver = window.MutationObserver;
globalThis.getComputedStyle = window.getComputedStyle;

new Function(fs.readFileSync('/home/claude/sift/content.js', 'utf8'))();

let pass = 0, fail = 0;
const check = (n, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${n.padEnd(48)} ${JSON.stringify(got)}`);
};

const PHONE = {
  source: '\\+?\\(?\\d{1,4}\\)?[-.\\s]?\\(?\\d{1,4}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{3,4}(?:[-.\\s]?\\d{1,4})?',
  flags: 'g', minDigits: 7, maxDigits: 15, mustMatch: '[+()\\-.]|\\d{7}', includeAttrs: false
};
const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const text = (q, opts = {}) => {
  let src = esc(q);
  if (opts.whole) src = `(?<![\\w])${src}(?![\\w])`;
  return { source: src, flags: opts.matchCase ? 'g' : 'gi', includeAttrs: false, eachOccurrence: true };
};

// A number broken across <b> and <span> must come back whole.
const phones = window.__sift.scan(PHONE).hits.map(h => h.text);
check('number split across tags reads as one', phones.includes('+234 803 555 0192'), true);
check('no bleed across the paragraph break', phones.some(p => p.includes('here') || /9999\D*7/.test(p)), false);

// Plain text search across an inline tag.
check('phrase spanning <em> is found', window.__sift.scan(text('quick brown fox')).hits.length, 2);
check('case-insensitive by default', window.__sift.scan(text('THE QUICK')).hits.length, 2);
check('match case narrows it', window.__sift.scan(text('THE QUICK', { matchCase: true })).hits.length, 1);
check('substring matches by default', window.__sift.scan(text('brown')).hits.length, 3);
check('whole word excludes brownstone', window.__sift.scan(text('brown', { whole: true })).hits.length, 2);
check('regex chars in query are literal', window.__sift.scan(text('fox jumps.*')).hits.length, 0);

// Context strings must not leak the NUL separator.
const ctx = window.__sift.scan(text('Ends here')).hits[0];
check('context is free of NUL padding', /\u0000/.test(ctx.before + ctx.after), false);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
