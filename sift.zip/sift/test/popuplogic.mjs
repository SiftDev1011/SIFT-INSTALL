/* Exercise popup.js's spec-building in isolation, with a stub DOM. */
import fs from 'fs';
import { JSDOM } from 'jsdom';

const html = fs.readFileSync('/home/claude/sift/popup.html', 'utf8')
  .replace('<script src="popup.js"></script>', '');
const dom = new JSDOM(html, { url: 'https://example.com' });
globalThis.window = dom.window;
globalThis.document = dom.window.document;
Object.defineProperty(globalThis, 'navigator', { value: dom.window.navigator, configurable: true });
globalThis.Blob = dom.window.Blob;
globalThis.chrome = {
  tabs: { query: async () => [{ id: 1 }] },
  scripting: { executeScript: async () => [] }
};

let src = fs.readFileSync('/home/claude/sift/popup.js', 'utf8')
  .replace(/^boot\(\);$/m, '')                       // no live tab to boot against
  .concat('\nglobalThis.__T = { buildSpec, PRESETS, escapeRe, showRows, setActive: p => (active = p) };');
new Function(src)();

const { buildSpec, PRESETS, escapeRe, showRows, setActive } = globalThis.__T;
const $ = s => document.querySelector(s);

let pass = 0, fail = 0;
const check = (n, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${n.padEnd(48)} ${JSON.stringify(got)}`);
};

setActive(PRESETS.find(p => p.id === 'text'));
showRows();

check('search preset is first chip', PRESETS[0].id, 'text');
check('empty query yields no spec', buildSpec(), null);

$('#query').value = 'lagos';
check('plain query is case-insensitive', buildSpec().flags, 'gi');
check('plain query lists every occurrence', buildSpec().eachOccurrence, true);
check('dedupe auto-off while searching', $('#dedupe').checked, false);

$('#matchCase').setAttribute('aria-pressed', 'true');
check('match case switches flags', buildSpec().flags, 'g');
$('#matchCase').setAttribute('aria-pressed', 'false');

$('#wholeWord').setAttribute('aria-pressed', 'true');
check('whole word wraps in boundaries', buildSpec().source, '(?<!\\w)lagos(?!\\w)');

$('#query').value = '+234';
check('leading symbol skips the left boundary', buildSpec().source, '\\+234(?!\\w)');
$('#wholeWord').setAttribute('aria-pressed', 'false');

$('#query').value = 'price: $50 (final)';
const spec = buildSpec();
check('regex metacharacters are escaped', spec.source, 'price: \\$50 \\(final\\)');
check('escaped query matches itself', new RegExp(spec.source).test('price: $50 (final)'), true);
check('escaped query is not a wildcard', new RegExp(spec.source).test('price: X50 Yfinal'), false);

// switching back to an extraction preset must restore dedupe
setActive(PRESETS.find(p => p.id === 'phone'));
showRows();
check('dedupe returns for extraction presets', $('#dedupe').checked, true);
check('phone spec keeps its digit guards', buildSpec().minDigits, 7);
check('query row hidden off search preset', $('#queryRow').hidden, true);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
