import { JSDOM } from 'jsdom';
import fs from 'fs';

const dom = new JSDOM(`<!doctype html><html><body><div id="feed"></div></body></html>`,
  { url: 'https://example.com', pretendToBeVisual: true });
const { window } = dom;
const { document } = window;

window.Element.prototype.checkVisibility = () => true;
window.Range.prototype.getBoundingClientRect = () => ({ top: 0, left: 0, width: 10, height: 10 });
window.Element.prototype.getBoundingClientRect = () => ({ top: 0, left: 0, width: 10, height: 10 });
window.Element.prototype.scrollIntoView = function () {};

globalThis.window = window;
globalThis.document = document;
globalThis.Node = window.Node;
globalThis.NodeFilter = window.NodeFilter;
globalThis.MutationObserver = window.MutationObserver;
globalThis.getComputedStyle = window.getComputedStyle;

/* ---- fake an infinite feed: 5 pages of 10, each fetched on scroll ---- */
const ROW_H = 200, PAGE = 10, MAX_PAGES = 5;
let loaded = 0, pages = 0, scrollY = 0, fetching = false;

Object.defineProperty(window, 'innerHeight', { value: 600, configurable: true });
Object.defineProperty(window, 'scrollY', { get: () => scrollY, configurable: true });
Object.defineProperty(window.document.documentElement, 'scrollHeight', {
  get: () => Math.max(loaded * ROW_H, 600), configurable: true
});

function loadPage() {
  const feed = document.getElementById('feed');
  for (let i = 0; i < PAGE; i++) {
    loaded++;
    const row = document.createElement('article');
    row.innerHTML = `<p>Seller ${loaded} — +234 803 ${String(100 + loaded).padStart(3, '0')} ${1000 + loaded}</p>`;
    feed.appendChild(row);
  }
  pages++;
}

function maybeFetch() {
  const h = window.document.documentElement.scrollHeight;
  if (fetching || pages >= MAX_PAGES) return;
  if (scrollY + window.innerHeight >= h - 120) {
    fetching = true;
    setTimeout(() => { loadPage(); fetching = false; }, 120);  // network latency
  }
}

window.scrollBy = (x, y) => {
  scrollY = Math.max(0, Math.min(scrollY + y, window.document.documentElement.scrollHeight - window.innerHeight));
  maybeFetch();
};
window.scrollTo = arg => { scrollY = typeof arg === 'object' ? arg.top : arguments[1] || 0; };

loadPage();  // first page is server-rendered

const SPEC = {
  presetId: 'phone',
  source: '\\+?\\(?\\d{1,4}\\)?[-.\\s]?\\(?\\d{1,4}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{3,4}(?:[-.\\s]?\\d{1,4})?',
  flags: 'g', minDigits: 7, maxDigits: 15, mustMatch: '[+()\\-.]|\\d{7}',
  includeAttrs: false, live: true
};

new Function(fs.readFileSync('/home/claude/sift/content.js', 'utf8'))();

let pass = 0, fail = 0;
const check = (name, got, want) => {
  const ok = got === want; ok ? pass++ : fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name.padEnd(46)} got ${got}  want ${want}`);
};

// A plain scan only ever sees page one.
const plain = window.__sift.scan(SPEC);
check('plain scan sees only the loaded page', plain.hits.length, 10);

// Harvest should walk the whole feed.
const t0 = Date.now();
const out = await window.__sift.harvest(SPEC, { settle: 260, maxSteps: 60 });
const secs = ((Date.now() - t0) / 1000).toFixed(1);

check('harvest pulls every page', out.hits.length, 50);
check('harvest reports completion', out.done, true);
check('all 5 pages were fetched', pages, 5);
check('scroll position restored to top', scrollY, 0);
check('results carry page positions', out.hits.every(h => h.position >= 0 && h.position <= 1), true);
check('terminates instead of spinning', Number(secs) < 12, true);
console.log(`      harvest took ${secs}s for ${out.hits.length} numbers across ${pages} pages`);

// Harvest again on an exhausted feed — must not hang.
const again = await window.__sift.harvest(SPEC, { settle: 200, maxSteps: 60 });
check('re-harvest on a finished feed stops fast', again.hits.length, 50);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
