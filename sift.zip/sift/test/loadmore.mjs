import { JSDOM } from 'jsdom';
import fs from 'fs';

const dom = new JSDOM(`<!doctype html><html><body>
  <div id="feed"></div>
  <form id="searchform"><input type="submit" value="Show more results"></form>
  <a id="pager" href="/page/2">Load more</a>
  <button id="filters">Show more filters</button>
  <button id="less">Show less</button>
  <button id="real">Load more</button>
  <button id="disabled" disabled>Load more items</button>
</body></html>`, { url: 'https://example.com/search?q=anime', pretendToBeVisual: true });

const { window } = dom; const { document } = window;
window.Element.prototype.checkVisibility = () => true;
window.Range.prototype.getBoundingClientRect = () => ({ top: 0, left: 0, width: 10, height: 10 });
window.Element.prototype.scrollIntoView = function () {};
globalThis.window = window; globalThis.document = document;
globalThis.Node = window.Node; globalThis.NodeFilter = window.NodeFilter;
globalThis.MutationObserver = window.MutationObserver;
globalThis.getComputedStyle = window.getComputedStyle;
globalThis.location = window.location;

/* geometry: the real button sits lowest on the page */
const tops = { searchform: 100, pager: 200, filters: 300, less: 400, real: 900, disabled: 950 };
window.Element.prototype.getBoundingClientRect = function () {
  return { top: tops[this.id] ?? 0, left: 0, width: 80, height: 20 };
};

/* the button loads a page of results, up to 4 times, then goes inert */
let loaded = 0, pagesClicked = 0;
const addRows = n => {
  const feed = document.getElementById('feed');
  for (let i = 0; i < n; i++) {
    loaded++;
    const r = document.createElement('p');
    r.textContent = `Seller ${loaded} +234 803 ${String(100 + loaded).padStart(3, '0')} ${1000 + loaded}`;
    feed.appendChild(r);
  }
};
document.getElementById('real').addEventListener('click', () => {
  if (pagesClicked >= 4) return;             // exhausted — button stays but does nothing
  pagesClicked++;
  setTimeout(() => addRows(10), 100);
});

let scrollY = 0;
Object.defineProperty(window, 'innerHeight', { value: 600, configurable: true });
Object.defineProperty(window, 'scrollY', { get: () => scrollY, configurable: true });
Object.defineProperty(document.documentElement, 'scrollHeight', {
  get: () => Math.max(loaded * 100, 600), configurable: true
});
window.scrollBy = (x, y) => { scrollY = Math.max(0, Math.min(scrollY + y, document.documentElement.scrollHeight - 600)); };
window.scrollTo = () => { scrollY = 0; };

addRows(10);  // server-rendered first page

new Function(fs.readFileSync('/home/claude/sift/content.js', 'utf8'))();

const SPEC = {
  source: '\\+?\\(?\\d{1,4}\\)?[-.\\s]?\\(?\\d{1,4}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{3,4}(?:[-.\\s]?\\d{1,4})?',
  flags: 'g', minDigits: 7, maxDigits: 15, mustMatch: '[+()\\-.]|\\d{7}',
  includeAttrs: false, live: true
};

let pass = 0, fail = 0;
const check = (n, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${n.padEnd(50)} ${JSON.stringify(got)}`);
};

check('plain scan sees only page one', window.__sift.scan(SPEC).hits.length, 10);

const t0 = Date.now();
const out = await window.__sift.harvest(SPEC, { settle: 200, maxSteps: 40, clickWaitMs: 1500 });
const secs = ((Date.now() - t0) / 1000).toFixed(1);

check('clicker pulled every page', out.hits.length, 50);
check('clicked exactly the 4 live pages', pagesClicked, 4);
check('gave up on the dead button quickly', out.clicked <= 6, true);
check('never submitted the form (page intact)', document.getElementById('searchform') !== null, true);
check('finished in reasonable time', Number(secs) < 20, true);
console.log(`      ${secs}s · ${out.clicked} clicks · ${out.hits.length} numbers`);

// opting out must skip clicking entirely
loaded = 0; pagesClicked = 0; scrollY = 0;
document.getElementById('feed').innerHTML = '';
addRows(10);
const off = await window.__sift.harvest({ ...SPEC, clickMore: false }, { settle: 150, maxSteps: 12 });
check('clickMore:false leaves the button alone', pagesClicked, 0);
check('and still returns what was loaded', off.hits.length, 10);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
