import { JSDOM } from 'jsdom';
import fs from 'fs';

const dom = new JSDOM(`<!doctype html><html><body><div id="feed"></div></body></html>`,
  { url: 'https://example.com', pretendToBeVisual: true });
const { window } = dom;
const { document } = window;

// jsdom has no layout engine, so vouch for visibility and give ranges a fake position.
window.Element.prototype.checkVisibility = () => true;
window.Range.prototype.getBoundingClientRect = function () {
  return { top: 0, left: 0, width: 10, height: 10 };
};
window.Element.prototype.getBoundingClientRect = function () {
  return { top: 0, left: 0, width: 10, height: 10 };
};
window.Element.prototype.scrollIntoView = function () {};

globalThis.window = window;
globalThis.document = document;
globalThis.Node = window.Node;
globalThis.NodeFilter = window.NodeFilter;
globalThis.MutationObserver = window.MutationObserver;
globalThis.getComputedStyle = window.getComputedStyle;

let uid = 0;
function addItems(n, prefix = '+234 803') {
  const feed = document.getElementById('feed');
  for (let i = 0; i < n; i++) {
    uid++;
    const row = document.createElement('article');
    row.className = 'row';
    row.innerHTML = `<h3>Vendor ${uid}</h3>
      <p>Call ${prefix} ${String(100 + uid).padStart(3, '0')} ${String(1000 + uid)}</p>
      <a href="tel:+2348090000${String(uid).padStart(3, '0')}">tap to call</a>`;
    feed.appendChild(row);
  }
}

const SPEC = {
  presetId: 'phone',
  source: '\\+?\\(?\\d{1,4}\\)?[-.\\s]?\\(?\\d{1,4}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{3,4}(?:[-.\\s]?\\d{1,4})?',
  flags: 'g', minDigits: 7, maxDigits: 15, mustMatch: '[+()\\-.]|\\d{7}',
  includeAttrs: true, live: true
};

// Load the content script into this window's global scope.
const code = fs.readFileSync('/home/claude/sift/content.js', 'utf8');
new Function(code)();

const wait = ms => new Promise(r => setTimeout(r, ms));
const uniq = hits => new Set(hits.filter(h => h.kind === 'text').map(h => h.text.replace(/\D/g, ''))).size;
const uniqAttr = hits => new Set(hits.filter(h => h.kind === 'href').map(h => h.text.replace(/\D/g, ''))).size;
let pass = 0, fail = 0;
const check = (name, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name.padEnd(46)} got ${got}  want ${want}`);
};

// 1 — initial page load
addItems(10);
const first = window.__sift.scan(SPEC);
check('initial scan finds 10 rows', uniq(first.hits), 10);
check('deep scan reads all 10 tel: hrefs', uniqAttr(first.hits), 10);

// 2 — feed appends more (the infinite scroll case)
addItems(10);
await wait(400);
check('live mode picks up appended rows', uniq(window.__sift.collect().hits), 20);

// 3 — virtualised feed destroys rows it scrolled past
document.querySelectorAll('.row').forEach((r, i) => { if (i < 10) r.remove(); });
addItems(10);
await wait(400);
const afterVirt = window.__sift.collect().hits;
check('recycled rows stay in results', uniq(afterVirt), 30);

// 4 — dedupe: same number twice
addItems(1);
const dup = document.querySelectorAll('.row');
dup[dup.length - 1].cloneNode(true) && document.getElementById('feed').appendChild(dup[dup.length - 1].cloneNode(true));
await wait(400);
const withDupes = window.__sift.collect().hits;
check('exact duplicate merges into one row', uniq(withDupes), 31);
check('duplicate counted, not dropped', withDupes.some(h => h.dupes > 1), true);

// 5 — reveal on a destroyed node must not throw
const stale = afterVirt.find(h => h.text.includes('101') || h.text.includes('102'));
const revealed = stale ? window.__sift.reveal(stale.id) : { ok: 'n/a' };
check('reveal on recycled node returns cleanly', typeof revealed.ok, 'boolean');

// 6 — a broken regex must not crash the page
const bad = window.__sift.scan({ ...SPEC, source: '([unclosed' });
check('invalid regex reports an error', bad.error, 'bad-pattern');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
