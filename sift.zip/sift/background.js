/* Sift — background service worker
 *
 * Two sites now, two jobs:
 *  - SITE_BASE (sift-web) owns accounts, login, and the free-tier ad-gate.
 *    Status comes from here.
 *  - API_BASE (sift-backend) owns checkout (Paddle) and enterprise quotes.
 *    Nothing about whether you're unlocked lives there anymore.
 *
 * The big change from the previous version: there is no more anonymous
 * free tier. Every status check needs a signed-in account. If there's no
 * session token yet, plan is reported as 'signed_out' and the popup sends
 * people to sift-web to sign in — it does not fall back to letting them
 * use Sift anonymously the way the old device-id version did.
 */

const SITE_BASE = 'https://sift.name.ng'; // sift-web — swap to your real domain once deployed
const API_BASE = 'https://api.sift.name.ng';  // sift-backend — swap to your real domain once deployed
const STATUS_TTL_MS = 45 * 1000;
const ALARM_NAME = 'sift-refresh';

let statusCache = null;
let inFlight = null;

/* ---------------- session token ----------------
 * Handed to us by sift-web after login, via chrome.runtime.sendMessage —
 * see the onMessageExternal listener at the bottom of this file. This is
 * NOT a browser cookie; cross-site cookie behavior from an extension
 * service worker isn't reliable enough to build the whole gate on top
 * of, so sift-web mints a small, purpose-built token instead. */

async function getSessionToken() {
  const { sessionToken } = await chrome.storage.local.get('sessionToken');
  return sessionToken || null;
}

async function setSession(token, email) {
  await chrome.storage.local.set({ sessionToken: token, userEmail: email || null });
}

async function clearSession() {
  await chrome.storage.local.remove(['sessionToken', 'userEmail']);
  statusCache = null;
}

async function getUserEmail() {
  const { userEmail } = await chrome.storage.local.get('userEmail');
  return userEmail || null;
}

/* ---------------- status ----------------
 * plan is one of: 'signed_out' | 'free' | 'pro' | 'enterprise'.
 * 'signed_out' is new — it means "go log in", not "here's the anonymous
 * free tier" the way earlier versions worked. */

async function fetchStatus(force = false) {
  if (!force && statusCache && Date.now() - statusCache.fetchedAt < STATUS_TTL_MS) {
    return statusCache;
  }
  if (inFlight) return inFlight;

  inFlight = (async () => {
    const token = await getSessionToken();
    if (!token) {
      statusCache = signedOutStatus();
      updateBadge(statusCache);
      return statusCache;
    }

    try {
      const res = await fetch(`${SITE_BASE}/api/ads/session/status`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.status === 401) {
        // Token expired or was revoked server-side — same as never having
        // logged in, so clear it rather than keep retrying with it.
        await clearSession();
        statusCache = signedOutStatus();
      } else if (!res.ok) {
        throw new Error(`status ${res.status}`);
      } else {
        const data = await res.json();
        statusCache = { ...data, fetchedAt: Date.now(), offline: false };
      }
    } catch (err) {
      // Network blip — fail toward "locked", but keep whatever we last
      // knew rather than discarding it outright.
      statusCache = statusCache
        ? { ...statusCache, fetchedAt: Date.now(), offline: true }
        : { ...signedOutStatus(), offline: true };
    }
    updateBadge(statusCache);
    return statusCache;
  })();

  const result = await inFlight;
  inFlight = null;
  return result;
}

function signedOutStatus() {
  return { plan: 'signed_out', accessUntil: null, adsWatchedInCycle: 0, adsRequired: 5, now: Date.now(), fetchedAt: Date.now() };
}

function hasAccess(status) {
  if (!status) return false;
  if (status.plan === 'pro' || status.plan === 'enterprise') return true;
  if (status.plan === 'signed_out') return false;
  return Boolean(status.accessUntil && status.accessUntil > Date.now());
}

function updateBadge(status) {
  if (!status) return;
  if (status.plan === 'pro' || status.plan === 'enterprise') {
    chrome.action.setBadgeText({ text: '' });
    return;
  }
  if (status.plan === 'signed_out') {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#A1A1AA' });
    return;
  }
  if (status.accessUntil && status.accessUntil > Date.now()) {
    const mins = Math.max(1, Math.ceil((status.accessUntil - Date.now()) / 60000));
    chrome.action.setBadgeText({ text: String(mins) });
    chrome.action.setBadgeBackgroundColor({ color: '#E5484D' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

/* ---------------- keep the countdown honest while the popup is closed ---------------- */

chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === ALARM_NAME) fetchStatus(true);
});
chrome.runtime.onStartup.addListener(() => fetchStatus(true));
chrome.runtime.onInstalled.addListener(() => fetchStatus(true));

/* ---------------- popup -> background ---------------- */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handleMessage(msg).then(sendResponse);
  return true; // keep the channel open for the async response
});

async function handleMessage(msg) {
  switch (msg.type) {
    case 'GET_STATUS': {
      const status = await fetchStatus(msg.force);
      return { ok: true, status, hasAccess: hasAccess(status) };
    }

    // One action now covers both "not signed in" and "signed in but
    // still has ads left this cycle" — sift-web's /profile page checks
    // which one applies and shows the right thing, so the popup doesn't
    // need to know or care which case it is.
    case 'OPEN_PROFILE': {
      chrome.tabs.create({ url: `${SITE_BASE}/profile?ext=${chrome.runtime.id}` });
      return { ok: true };
    }

    case 'OPEN_CHECKOUT': {
      const email = await getUserEmail();
      chrome.tabs.create({
        url: `${API_BASE}/checkout?plan=${encodeURIComponent(msg.plan)}&email=${encodeURIComponent(email || '')}&ext=${chrome.runtime.id}`
      });
      return { ok: true };
    }

    case 'OPEN_ENTERPRISE': {
      chrome.tabs.create({ url: `${SITE_BASE}/enterprise?ext=${chrome.runtime.id}` });
      return { ok: true };
    }

    default:
      return { ok: false, error: 'unknown message type: ' + msg.type };
  }
}

/* ---------------- sift-web / sift-backend -> background ----------------
 * Only works from origins listed in manifest.json's externally_connectable.
 *
 *  SIFT_SESSION   — sift-web hands us a token right after login (see
 *                   sift-web's profile/login pages). This is how the
 *                   extension finds out someone is signed in at all.
 *  SIFT_SIGNED_OUT— sent when the person signs out on the website, so the
 *                   extension locks again immediately rather than waiting
 *                   for its cached status to expire.
 *  SIFT_UNLOCKED  — sift-backend's checkout success page sends this once
 *                   Paddle confirms payment, same as before.
 */

chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'SIFT_SESSION' && msg.token) {
    (async () => {
      await setSession(msg.token, msg.email);
      const status = await fetchStatus(true);
      sendResponse({ ok: true, hasAccess: hasAccess(status) });
    })();
    return true;
  }

  if (msg && msg.type === 'SIFT_SIGNED_OUT') {
    clearSession().then(() => {
      updateBadge(signedOutStatus());
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg && msg.type === 'SIFT_UNLOCKED') {
    fetchStatus(true).then(status => sendResponse({ ok: true, hasAccess: hasAccess(status) }));
    return true;
  }

  sendResponse({ ok: false });
});
