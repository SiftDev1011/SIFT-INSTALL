/* Sift Discovery — map lookup, run from the PERSON'S OWN connection.
 *
 * Finding businesses needs three free public services (Nominatim/Photon to turn "Lagos"
 * into a map rectangle, Overpass to list businesses inside it). Those services refuse or
 * rate-limit the shared addresses of hosting companies like Render ("ECONNREFUSED",
 * "HTTP 429", timeouts) but answer an ordinary browser without any trouble — so the
 * extension asks them itself and hands the finished list to Sift's server, which then does
 * the part only a server can do well: reading each business's website for contact details.
 *
 * What to look for (which map tags, which words) comes from the server — GET /jobs/:id/plan —
 * so this file has no opinion of its own about business types.
 *
 * It is a close sibling of sift-backend/lib/osm.js. If you change the way one asks the map
 * services, change the other too.
 */
(function (root) {
  'use strict';

  const DEFAULT_MAP = {
    overpass: [
      'https://overpass-api.de/api/interpreter',
      'https://overpass.private.coffee/api/interpreter',
      'https://overpass.kumi.systems/api/interpreter',
      'https://overpass.openstreetmap.fr/api/interpreter',
      'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
      'https://lz4.overpass-api.de/api/interpreter'
    ],
    nominatim: 'https://nominatim.openstreetmap.org',
    photon: 'https://photon.komoot.io'
  };

  // Timings can be shortened (tests do) by setting SIFT_MAP_TIMINGS before this file loads.
  const T = Object.assign({ attemptMs: 22000, nameAttemptMs: 15000, geocodeMs: 10000, totalMs: 70000, retryPauseMs: 2000 }, root.SIFT_MAP_TIMINGS || {});

  class MapError extends Error {
    constructor(code, message) {
      super(message);
      this.name = 'MapError';
      this.code = code; // REGION_REQUIRED | REGION_NOT_FOUND | GEOCODER_UNAVAILABLE | OVERPASS_UNAVAILABLE
    }
  }

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const mapConfig = () => Object.assign({}, DEFAULT_MAP, (root.SIFT && root.SIFT.MAP) || {});

  function describeError(err) {
    if (!err) return 'unknown error';
    const parts = [err.message];
    if (err.cause) {
      if (err.cause.code) parts.push(err.cause.code);
      if (err.cause.message && err.cause.message !== err.message) parts.push(err.cause.message);
    }
    return [...new Set(parts.filter(Boolean))].join(' / ');
  }

  async function fetchWithTimeout(url, options, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, Object.assign({}, options, { signal: controller.signal }));
    } catch (err) {
      if (err && err.name === 'AbortError') throw new Error('timed out after ' + Math.round(timeoutMs / 1000) + 's');
      throw err;
    } finally {
      clearTimeout(timer);
    }
  }

  function cleanWord(text) {
    return String(text || '').replace(/[^\p{L}\p{N}\s'&-]/gu, ' ').replace(/\s+/g, ' ').trim().slice(0, 40);
  }
  const safeTagPart = text => (/^[a-z0-9_:-]{1,40}$/.test(String(text || '').trim().toLowerCase()) ? String(text).trim().toLowerCase() : null);

  /* ---------------- 1. place name -> map rectangle ---------------- */

  const geocodeCache = new Map();

  async function geocodeNominatim(region) {
    const res = await fetchWithTimeout(mapConfig().nominatim + '/search?q=' + encodeURIComponent(region) + '&format=json&limit=1',
      { headers: { Accept: 'application/json' } }, T.geocodeMs);
    if (!res.ok) throw new Error('Nominatim HTTP ' + res.status);
    const data = await res.json();
    if (Array.isArray(data) && data.length && data[0].boundingbox) {
      const b = data[0].boundingbox.map(Number);
      return { south: b[0], north: b[1], west: b[2], east: b[3] };
    }
    return null;
  }

  async function geocodePhoton(region) {
    const res = await fetchWithTimeout(mapConfig().photon + '/api/?q=' + encodeURIComponent(region) + '&limit=1',
      { headers: { Accept: 'application/json' } }, T.geocodeMs);
    if (!res.ok) throw new Error('Photon HTTP ' + res.status);
    const data = await res.json();
    const feature = data && data.features && data.features[0];
    if (!feature) return null;
    const extent = feature.properties && feature.properties.extent; // [west, north, east, south]
    if (Array.isArray(extent) && extent.length === 4) {
      const e = extent.map(Number);
      return { south: e[3], north: e[1], west: e[0], east: e[2] };
    }
    const c = (feature.geometry && feature.geometry.coordinates) || [];
    if (typeof c[0] !== 'number' || typeof c[1] !== 'number') return null;
    const pad = 0.05; // a single point (a village): about 5 km around it
    return { south: c[1] - pad, north: c[1] + pad, west: c[0] - pad, east: c[0] + pad };
  }

  async function resolveRegion(region) {
    const key = String(region || '').trim().toLowerCase();
    if (!key) throw new MapError('REGION_REQUIRED', 'Add a place to search in, like "Lagos, Nigeria".');
    if (geocodeCache.has(key)) return geocodeCache.get(key);

    let answered = false;
    for (const lookup of [geocodeNominatim, geocodePhoton]) {
      try {
        const bbox = await lookup(region.trim());
        answered = true;
        if (bbox) { geocodeCache.set(key, bbox); return bbox; }
      } catch (err) {
        console.warn('[map] place lookup failed (' + describeError(err) + '), trying next...');
      }
    }
    if (answered) throw new MapError('REGION_NOT_FOUND', 'We couldn\'t find "' + region.trim() + '" on the map. Check the spelling, or try a nearby city.');
    throw new MapError('GEOCODER_UNAVAILABLE', 'The place-lookup service is not responding right now.');
  }

  /* ---------------- 2. Overpass: businesses inside the rectangle ---------------- */

  const health = new Map(); // endpoint -> { failures, coolUntil }

  function orderedEndpoints() {
    const now = Date.now();
    const healthy = [];
    const cooling = [];
    for (const endpoint of mapConfig().overpass) {
      const h = health.get(endpoint);
      (h && h.coolUntil > now ? cooling : healthy).push(endpoint);
    }
    for (let i = healthy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [healthy[i], healthy[j]] = [healthy[j], healthy[i]];
    }
    cooling.sort((a, b) => health.get(a).coolUntil - health.get(b).coolUntil);
    return healthy.concat(cooling);
  }

  function markFailure(endpoint, retryAfterMs) {
    const h = health.get(endpoint) || { failures: 0, coolUntil: 0 };
    h.failures += 1;
    h.coolUntil = Date.now() + (retryAfterMs || Math.min(30000 * Math.pow(2, h.failures - 1), 10 * 60 * 1000));
    health.set(endpoint, h);
  }

  function retryAfter(res) {
    const header = res.headers && res.headers.get && res.headers.get('retry-after');
    const seconds = Number(header);
    return header && Number.isFinite(seconds) ? Math.min(seconds, 120) * 1000 : 0;
  }

  async function overpassOnce(endpoint, ql, timeoutMs) {
    const res = await fetchWithTimeout(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: new URLSearchParams({ data: ql }).toString()
    }, timeoutMs);
    if (!res.ok) {
      const error = new Error('Overpass HTTP ' + res.status + (res.statusText ? ': ' + res.statusText : ''));
      error.retryAfterMs = retryAfter(res);
      throw error;
    }
    let json;
    try { json = await res.json(); } catch (e) { throw new Error('Overpass sent something that was not data'); }
    const elements = json.elements || [];
    if (json.remark && /runtime error/i.test(json.remark) && elements.length === 0) throw new Error('Overpass gave up: ' + json.remark);
    return elements;
  }

  async function runOverpass(ql, options) {
    const attempts = (options && options.attempts) || 2;
    const timeoutMs = (options && options.timeoutMs) || T.attemptMs;
    const deadline = Date.now() + T.totalMs;
    let lastError = null;

    for (let round = 0; round < attempts; round++) {
      for (const endpoint of orderedEndpoints()) {
        if (Date.now() >= deadline) break;
        try {
          const elements = await overpassOnce(endpoint, ql, Math.min(timeoutMs, Math.max(deadline - Date.now(), 1000)));
          health.delete(endpoint);
          return elements;
        } catch (err) {
          lastError = err;
          markFailure(endpoint, err.retryAfterMs);
          console.warn('[map] ' + endpoint + ' failed (' + describeError(err) + '), trying next...');
        }
      }
      if (Date.now() >= deadline) break;
      if (round < attempts - 1) await sleep(T.retryPauseMs * (round + 1));
    }
    throw new MapError('OVERPASS_UNAVAILABLE', 'All Overpass API endpoints failed. Last error: ' + describeError(lastError));
  }

  /** Query 1: exact tags only (office=lawyer …) — cheap and reliable. */
  function buildTagQuery(tags, bbox, limit) {
    const box = '(' + bbox.south + ',' + bbox.west + ',' + bbox.north + ',' + bbox.east + ')';
    let ql = '[out:json][timeout:20];\n(\n';
    tags.forEach(t => { ql += '  nwr["' + t.key + '"="' + t.value + '"]' + box + ';\n'; });
    return ql + ');\nout center ' + limit + ';\n';
  }

  const NAME_GROUPS = ['shop', 'amenity', 'office', 'craft', 'healthcare', 'tourism', 'leisure'];

  /** Query 2 (optional): whole words in business NAMES, only among things tagged as shops/offices/etc. */
  function buildNameQuery(nameWords, tags, bbox, limit) {
    const box = '(' + bbox.south + ',' + bbox.west + ',' + bbox.north + ',' + bbox.east + ')';
    const pattern = '(^|[^A-Za-z])(' + nameWords.join('|') + ')s?([^A-Za-z]|$)';
    const keys = tags.map(t => t.key).filter(k => NAME_GROUPS.indexOf(k) !== -1);
    const groups = tags.length ? Array.from(new Set(keys.concat(['office', 'shop', 'amenity', 'craft']))) : NAME_GROUPS;
    let ql = '[out:json][timeout:15];\n(\n';
    groups.forEach(g => { ql += '  nwr["' + g + '"]["name"~"' + pattern + '",i]' + box + ';\n'; });
    return ql + ');\nout center ' + limit + ';\n';
  }

  function formatAddress(tags) {
    const parts = [tags['addr:housenumber'], tags['addr:street'], tags['addr:suburb'] || tags['addr:district'],
      tags['addr:city'] || tags['addr:town'] || tags['addr:state'], tags['addr:country']].filter(Boolean);
    if (parts.length) return parts.join(', ');
    return tags['addr:full'] || null;
  }

  function parseElement(el) {
    const tags = el.tags || {};
    const center = el.center || {};
    return {
      osmId: el.type + '/' + el.id,
      businessName: tags.name || tags['name:en'] || tags.brand || tags.operator || null,
      email: tags.email || tags['contact:email'] || null,
      phone: tags.phone || tags['contact:phone'] || tags['phone:mobile'] || null,
      website: tags.website || tags['contact:website'] || tags.url || null,
      address: formatAddress(tags),
      lat: el.lat || center.lat || null,
      lon: el.lon || center.lon || null
    };
  }

  const skipElement = el => {
    const t = el.tags || {};
    return (!t.name && !t.brand) || t.highway === 'bus_stop' || t.public_transport === 'platform' || t.highway === 'traffic_signals';
  };

  /* ---------------- 3. last resort: Nominatim search ---------------- */

  async function nominatimCandidates(terms, bbox, limit) {
    const results = [];
    const seen = new Set();
    const list = terms.slice(0, 3);
    for (let i = 0; i < list.length; i++) {
      if (i > 0) await sleep(1100); // Nominatim asks for at most one request a second
      const url = mapConfig().nominatim + '/search?q=' + encodeURIComponent(list[i]) + '&format=jsonv2&limit=40&bounded=1'
        + '&viewbox=' + [bbox.west, bbox.north, bbox.east, bbox.south].join(',') + '&extratags=1&addressdetails=0';
      const res = await fetchWithTimeout(url, { headers: { Accept: 'application/json' } }, T.geocodeMs);
      if (!res.ok) throw new Error('Nominatim HTTP ' + res.status);
      const items = await res.json();
      for (const item of Array.isArray(items) ? items : []) {
        const extra = item.extratags || {};
        const name = item.name || String(item.display_name || '').split(',')[0].trim();
        const id = item.osm_type + '/' + item.osm_id;
        if (!name || seen.has(id)) continue;
        seen.add(id);
        results.push({
          osmId: id, businessName: name,
          email: extra.email || extra['contact:email'] || null,
          phone: extra.phone || extra['contact:phone'] || null,
          website: extra.website || extra['contact:website'] || null,
          address: String(item.display_name || '').split(',').slice(1, 4).join(',').trim() || null,
          lat: Number(item.lat) || null, lon: Number(item.lon) || null
        });
        if (results.length >= limit) return results;
      }
    }
    return results;
  }

  /* ---------------- putting it together ---------------- */

  /**
   * Looks up candidate businesses for a search plan (from GET /jobs/:id/plan).
   * Resolves with a list of { osmId, businessName, email, phone, website, address, lat, lon }.
   * Rejects with a MapError (see its .code).
   */
  async function lookupCandidates(plan) {
    const tags = (plan.tags || []).filter(t => safeTagPart(t.key) && safeTagPart(t.value));
    const nameWords = (plan.nameWords || []).map(cleanWord).filter(w => w.length > 2).slice(0, 8);
    const searchTerms = (plan.searchTerms || []).map(cleanWord).filter(Boolean);
    const cap = Math.min(Math.max(Number(plan.limit) || 50, 1), 400);
    if (!tags.length && !nameWords.length) return []; // nothing to look for — and never "everything"

    const bbox = await resolveRegion(plan.region);

    const out = [];
    const seenIds = new Set();
    const seenNames = new Set();
    const add = candidates => {
      for (const c of candidates) {
        if (!c.businessName) continue;
        const norm = c.businessName.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (seenIds.has(c.osmId) || (norm && seenNames.has(norm))) continue;
        seenIds.add(c.osmId);
        if (norm) seenNames.add(norm);
        out.push(c);
        if (out.length >= cap) return;
      }
    };
    const addElements = elements => add(elements.filter(el => !skipElement(el)).map(parseElement));

    let coreError = null;
    let nameError = null;
    if (tags.length) {
      try { addElements(await runOverpass(buildTagQuery(tags, bbox, cap * 2))); } catch (err) { coreError = err; }
    }
    const thin = tags.length > 0 && !coreError && out.length < Math.min(cap, 30);
    if (nameWords.length && (!tags.length || thin || coreError)) {
      try {
        addElements(await runOverpass(buildNameQuery(nameWords, tags, bbox, cap * 2), { attempts: tags.length ? 1 : 2, timeoutMs: T.nameAttemptMs }));
      } catch (err) {
        nameError = err;
        if (tags.length && !coreError) console.warn('[map] name search skipped (' + describeError(err) + ')');
      }
    }

    const overpassDown = tags.length ? (coreError && (nameError || !nameWords.length)) : nameError;
    if (!out.length && overpassDown) {
      const terms = searchTerms.length ? searchTerms : tags.map(t => t.value.replace(/_/g, ' '));
      try { add(await nominatimCandidates(Array.from(new Set(terms)), bbox, cap)); } catch (err) { console.warn('[map] Nominatim fallback failed (' + describeError(err) + ')'); }
      if (!out.length) throw coreError || nameError;
    }
    return out.slice(0, cap);
  }

  function _resetForTests() { geocodeCache.clear(); health.clear(); }

  const api = { lookupCandidates, resolveRegion, MapError, describeError, buildTagQuery, buildNameQuery, _resetForTests };
  root.SiftMap = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
