/* Sift Discovery — the ONLY place you change web addresses.
 *
 * SIFT_MODE decides which pair of addresses the extension talks to:
 *   'live'  -> your real website and real backend (what customers use)
 *   'local' -> the copies running on your own computer (for testing)
 *
 * To test on your computer: change 'live' to 'local' below, then press the
 * little "reload" arrow on this extension's card at chrome://extensions.
 * Change it back to 'live' before you package the extension for customers.
 *
 * If your real domains are different from the ones below, edit them here
 * AND in manifest.json (the "host_permissions" and "externally_connectable"
 * lists) — Chrome needs to be told about every website the extension may talk to.
 */
const SIFT_MODE = 'live';

const SIFT_ADDRESSES = {
  live:  { SITE_BASE: 'https://sift.name.ng',  API_BASE: 'https://api.sift.name.ng' }, // website (accounts, ads)  /  backend (Discovery, checkout)
  local: { SITE_BASE: 'http://localhost:3000', API_BASE: 'http://localhost:3001' }
};

// The free public map services the extension asks DIRECTLY, from the person's own connection
// (Render's shared address is refused or rate-limited by them; a person's browser is not).
// You normally never touch this. Chrome must be told about these sites too: see manifest.json.
const SIFT_MAP = {
  overpass: [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.openstreetmap.fr/api/interpreter',
    'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
    'https://lz4.overpass-api.de/api/interpreter'
  ],
  nominatim: 'https://nominatim.openstreetmap.org',
  photon: 'https://photon.komoot.io'
};

const SIFT = { MODE: SIFT_MODE, ...SIFT_ADDRESSES[SIFT_MODE], MAP: SIFT_MAP };
globalThis.SIFT = SIFT; // so the map-lookup file can see these settings too
