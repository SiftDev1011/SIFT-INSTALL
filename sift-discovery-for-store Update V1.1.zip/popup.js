/* Sift Discovery — popup
 *
 * What this file does, in plain terms:
 *  1. Asks background.js "is this person signed in, and do they have access?"
 *     (same account and same free ads / Pro plan as Sift Extractor) and shows
 *     either the unlock screen or the search form.
 *  2. Sends a search to the Sift backend and then only WATCHES it. The search
 *     itself runs on the server, so closing this window never stops it —
 *     reopen it and it picks up where it was.
 *  3. Shows results as they arrive and lets you copy emails or export a CSV.
 *
 * Web addresses live in config.js, not here.
 */

const $ = sel => document.querySelector(sel);

const FINISHED = ['completed', 'failed', 'cancelled'];
const POLL_MS = 2000;
const GAUGE_TICKS = 24;
const VOLUME_PRESETS = [25, 50, 100, 250];
const LIVE_ROWS = 6; // how many of the newest finds to show while a search is running

const PHASE_TEXT = {
  preparing: 'Getting ready…',
  searching: 'Finding businesses on the map…',
  checking: 'Checking websites for contacts…'
};

const state = {
  status: null,   // { plan, accessUntil, adsWatchedInCycle, adsRequired } — null until background answers
  job: null,      // the search being shown (progress or results)
  results: [],
  pollToken: 0,   // bumping this stops any running poll loop
  starting: false
};

/* ---------------- small helpers ---------------- */

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function send(message) {
  return chrome.runtime.sendMessage(message).catch(() => null);
}

function hasAccess(status) {
  if (!status) return false;
  if (status.plan === 'pro' || status.plan === 'enterprise') return true;
  if (status.plan === 'signed_out') return false;
  return Boolean(status.accessUntil && status.accessUntil > Date.now());
}

function timeAgo(ts) {
  const secs = Math.max(0, Math.round((Date.now() - Number(ts)) / 1000));
  if (secs < 60) return 'just now';
  if (secs < 3600) return `${Math.round(secs / 60)} min ago`;
  if (secs < 86400) return `${Math.round(secs / 3600)} h ago`;
  return `${Math.round(secs / 86400)} d ago`;
}

function slug(text) {
  return String(text || 'search').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'search';
}

function isHttpUrl(value) {
  return /^https?:\/\//i.test(String(value || ''));
}

function shortSite(url) {
  return String(url).replace(/^https?:\/\/(www\.)?/i, '').replace(/\/$/, '');
}

/* ---------------- talking to the Sift backend ---------------- */

class ApiError extends Error {
  constructor(code, message, status, data) {
    super(message);
    this.code = code;
    this.status = status;
    this.data = data;
  }
}

function friendlyHttp(status) {
  if (status >= 500) return 'Something went wrong on our side. Try again in a moment.';
  if (status === 429) return 'Too many requests. Wait a moment and try again.';
  return 'That did not work. Try again.';
}

async function api(method, path, { body, blob } = {}) {
  const { sessionToken } = await chrome.storage.local.get('sessionToken');
  if (!sessionToken) throw new ApiError('not_signed_in', 'Sign in to use Sift Discovery.', 401);

  let res;
  try {
    res = await fetch(SIFT.API_BASE + path, {
      method,
      headers: {
        Authorization: `Bearer ${sessionToken}`,
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {})
      },
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch {
    throw new ApiError('network', "Can't reach Sift right now. Check your connection and try again.", 0);
  }

  if (res.ok && blob) return res.blob();

  let data = null;
  try { data = await res.json(); } catch { /* not JSON */ }
  if (res.ok) return data || {};
  throw new ApiError((data && data.error) || `http_${res.status}`, (data && data.message) || friendlyHttp(res.status), res.status, data);
}

/* ---------------- access: sign-in, free ads, plans ---------------- */

async function refreshAccess(force) {
  const res = await send({ type: 'GET_STATUS', force: !!force });
  if (!res || !res.ok) return;
  state.status = res.status;
  renderAccess();
}

function renderAccess() {
  const status = state.status;
  const unlocked = hasAccess(status);
  const signedOut = Boolean(status) && status.plan === 'signed_out';
  const viewing = Boolean(state.job);
  const showGate = Boolean(status) && (signedOut || (!unlocked && !viewing));

  $('#frame').classList.toggle('locked', showGate);
  if (showGate) renderGate(status);

  // Free access ran out while looking at a search: keep the results visible.
  $('#banner').hidden = !(Boolean(status) && !unlocked && !signedOut && viewing);

  renderFreeBadge(status);
  $('#start').disabled = !status || !unlocked || state.starting;
}

function renderGate(status) {
  const adsRow = $('#adsRow');
  if (status.plan === 'signed_out') {
    $('#gateCopy').textContent = 'Sign in to use Sift Discovery. One Sift account works in every Sift product — free accounts get 20 minutes after a few short ads.';
    $('#gateAction').textContent = 'Sign in';
    adsRow.hidden = true;
    return;
  }

  const required = status.adsRequired || 5;
  const watched = Math.min(status.adsWatchedInCycle || 0, required);
  $('#gateCopy').textContent = watched > 0
    ? "Finish this cycle's ads to keep going. Your 20 minutes unlock every Sift product."
    : 'Your free access has ended. Watch a few short ads for another 20 minutes — it unlocks every Sift product.';
  $('#gateAction').textContent = watched > 0 ? 'Finish on your profile' : 'Watch ads to unlock';

  const dots = $('#adsDots');
  dots.replaceChildren();
  for (let i = 0; i < required; i++) dots.appendChild(el('span', i < watched ? 'dot filled' : 'dot'));
  $('#adsText').textContent = `${watched} of ${required} ads watched`;
  adsRow.hidden = false;
}

function renderFreeBadge(status) {
  const badge = $('#freeBadge');
  if (!status || status.plan !== 'free' || !status.accessUntil || status.accessUntil <= Date.now()) {
    badge.hidden = true;
    return;
  }
  const mins = Math.max(0, Math.ceil((status.accessUntil - Date.now()) / 60000));
  badge.hidden = false;
  badge.textContent = `free access · ${mins} min left`;
}

/* ---------------- caliper scale ---------------- */

function buildGauge() {
  const gauge = $('#gauge');
  for (let i = 0; i < GAUGE_TICKS; i++) {
    const tick = document.createElement('i');
    tick.style.top = `calc(${(i / GAUGE_TICKS) * 100}% + 6px)`;
    gauge.appendChild(tick);
  }
}

function setGauge(ratio) {
  const clamped = Math.max(0, Math.min(1, ratio || 0));
  const lit = Math.round(clamped * GAUGE_TICKS);
  [...$('#gauge').children].forEach((tick, i) => tick.classList.toggle('on', i >= GAUGE_TICKS - lit));
  const caret = $('#caret');
  caret.style.opacity = lit ? '1' : '0';
  caret.style.top = `calc(${(1 - lit / GAUGE_TICKS) * 100}% + 7px)`;
}

/* ---------------- the search form ---------------- */

function pressed(node) { return node.getAttribute('aria-pressed') === 'true'; }

function buildVolumeChips() {
  const wrap = $('#volChips');
  for (const n of VOLUME_PRESETS) {
    const chip = el('button', 'chip', String(n));
    chip.type = 'button';
    chip.addEventListener('click', () => {
      $('#volume').value = String(n);
      syncVolumeChips();
      saveForm();
    });
    wrap.appendChild(chip);
  }
  syncVolumeChips();
}

function syncVolumeChips() {
  const current = Number($('#volume').value);
  [...$('#volChips').children].forEach((chip, i) => chip.setAttribute('aria-pressed', String(VOLUME_PRESETS[i] === current)));
}

function saveForm() {
  const must = {};
  document.querySelectorAll('#must .chip').forEach(chip => { must[chip.dataset.key] = pressed(chip); });
  chrome.storage.local.set({ discoveryForm: { query: $('#query').value, region: $('#region').value, volume: $('#volume').value, must } });
}

async function restoreForm() {
  const { discoveryForm } = await chrome.storage.local.get('discoveryForm');
  if (!discoveryForm) return;
  $('#query').value = discoveryForm.query || '';
  $('#region').value = discoveryForm.region || '';
  if (discoveryForm.volume) $('#volume').value = discoveryForm.volume;
  document.querySelectorAll('#must .chip').forEach(chip => {
    chip.setAttribute('aria-pressed', String(Boolean(discoveryForm.must && discoveryForm.must[chip.dataset.key])));
  });
  syncVolumeChips();
}

function showFormError(message) {
  const box = $('#formError');
  box.textContent = message;
  box.hidden = !message;
}

function readForm() {
  showFormError('');
  for (const id of ['#query', '#region', '#volume']) $(id).classList.remove('bad');

  const query = $('#query').value.trim();
  const region = $('#region').value.trim();
  const volume = Number($('#volume').value);

  if (!query) {
    $('#query').classList.add('bad');
    showFormError('Type the kind of business you want, like "bakeries".');
    return null;
  }
  if (!region) {
    $('#region').classList.add('bad');
    showFormError('Add a place — a city, state or country, like "Lagos, Nigeria".');
    return null;
  }
  if (!Number.isInteger(volume) || volume < 1 || volume > 1000) {
    $('#volume').classList.add('bad');
    showFormError('Pick a whole number from 1 to 1000.');
    return null;
  }

  const filters = { region };
  document.querySelectorAll('#must .chip').forEach(chip => { if (pressed(chip)) filters[chip.dataset.key] = true; });
  return { query, filters, requestedVolume: volume };
}

/* ---------------- views ---------------- */

function showView(name) {
  $('#viewForm').hidden = name !== 'form';
  $('#viewJob').hidden = name !== 'job';
}

function setNote(text, live) {
  const note = $('#note');
  note.replaceChildren();
  if (live) note.appendChild(el('span', 'live-dot'));
  note.appendChild(document.createTextNode(text));
}

function showJobError(message) {
  const box = $('#jobError');
  box.textContent = message || '';
  box.hidden = !message;
}

function contactButton(label, title, onClick) {
  const button = el('button', 'contact', label);
  button.type = 'button';
  button.title = title;
  button.addEventListener('click', () => onClick(button));
  return button;
}

function flash(button, text) {
  const original = button.dataset.label || button.textContent;
  button.dataset.label = original;
  button.textContent = text;
  button.classList.add('copied');
  setTimeout(() => { button.textContent = original; button.classList.remove('copied'); }, 1100);
}

function businessRow(r) {
  const row = el('div', 'biz');
  row.appendChild(el('div', 'name', r.business_name || 'Unnamed business'));
  if (r.address) row.appendChild(el('div', 'addr', r.address));

  const contacts = el('div', 'contacts');
  if (r.email) {
    contacts.appendChild(contactButton(r.email, 'Copy email', btn => navigator.clipboard.writeText(r.email).then(() => flash(btn, 'Copied'))));
  }
  if (r.phone) {
    contacts.appendChild(contactButton(r.phone, 'Copy phone number', btn => navigator.clipboard.writeText(r.phone).then(() => flash(btn, 'Copied'))));
  }
  if (r.website && isHttpUrl(r.website)) {
    contacts.appendChild(contactButton(shortSite(r.website), 'Open website', () => chrome.tabs.create({ url: r.website })));
  }
  if (contacts.children.length) row.appendChild(contacts);
  return row;
}

function renderJob() {
  const job = state.job;
  if (!job) return;

  const running = !FINISHED.includes(job.status);
  const found = job.matchesCount || 0;
  const wanted = job.requestedVolume || 0;
  const checked = job.candidatesChecked || 0;

  $('#jobQuery').textContent = job.rawQuery || 'Search';
  $('#jobWhere').textContent = (job.parsedFilters && job.parsedFilters.region) || '';
  $('#count').innerHTML = `<b>${Number(found)}</b> found`;
  $('#target').textContent = wanted ? `of ${wanted} wanted` : '';

  const ratio = wanted ? Math.min(1, found / wanted) : 0;
  $('#sweep').style.width = `${ratio * 100}%`;
  setGauge(ratio);

  // status line
  if (running) {
    const base = PHASE_TEXT[job.phase] || (job.status === 'pending' ? 'Finding businesses on the map…' : 'Working…');
    setNote(checked ? `${base} · ${checked} checked` : base, true);
  } else if (job.status === 'completed') {
    setNote(found >= wanted && wanted
      ? 'Done — you reached your target.'
      : `Done — that's every match we could find (${checked} businesses checked).`);
  } else if (job.status === 'cancelled') {
    setNote('Cancelled — here is what was found so far.');
  } else {
    setNote('This search did not finish.');
  }
  showJobError(job.status === 'failed' ? (job.errorMessage || 'Something went wrong while searching. Try again.') : '');

  // list: newest few while running, everything once finished
  const list = $('#list');
  list.replaceChildren();
  const rows = running ? state.results.slice(-LIVE_ROWS).reverse() : state.results;
  if (rows.length) {
    const frag = document.createDocumentFragment();
    rows.forEach(r => frag.appendChild(businessRow(r)));
    list.appendChild(frag);
  } else if (running) {
    const empty = el('div', 'empty');
    empty.append(el('b', '', 'Nothing yet.'), document.createTextNode('Matches show up here the moment they are found.'));
    list.appendChild(empty);
  } else if (job.status === 'completed') {
    const empty = el('div', 'empty');
    empty.append(
      el('b', '', 'No businesses matched.'),
      document.createTextNode('Try a broader business type, a bigger area, or turn off a "Must have" filter.')
    );
    list.appendChild(empty);
  }

  // buttons
  $('#cancel').hidden = !running;
  $('#again').hidden = running;
  $('#copyEmails').disabled = !state.results.some(r => r.email);
  $('#csv').disabled = !state.results.length || running;
}

/* ---------------- running a search ---------------- */

async function loadAllResults(jobId) {
  const all = [];
  for (let offset = 0; offset < 1000; offset += 500) {
    const page = await api('GET', `/api/discover/jobs/${encodeURIComponent(jobId)}/results?limit=500&offset=${offset}`);
    all.push(...(page.results || []));
    if (all.length >= (page.total || 0)) break;
  }
  return all;
}

async function onFinished(job) {
  state.pollToken++;
  await chrome.storage.local.remove(['activeJobId', 'finishedJobId']);
  send({ type: 'JOB_SEEN' });
  state.job = job;
  try {
    state.results = await loadAllResults(job.id);
  } catch (err) {
    state.results = [];
    showJobError(err.message);
  }
  renderJob();
  renderAccess();
}

async function watchJob(jobId) {
  const mine = ++state.pollToken;
  let failures = 0;
  let lastNudge = 0;

  while (mine === state.pollToken) {
    try {
      const { job } = await api('GET', `/api/discover/jobs/${encodeURIComponent(jobId)}`);
      if (mine !== state.pollToken) return;
      failures = 0;
      state.job = job;

      if (FINISHED.includes(job.status)) { await onFinished(job); return; }

      // Stuck "pending" for over 90 seconds: the background worker probably went to sleep mid-lookup. Nudge it.
      if (job.status === 'pending' && Date.now() - Number(job.createdAt || 0) > 90000 && Date.now() - lastNudge > 60000) {
        lastNudge = Date.now();
        send({ type: 'RESUME_PENDING', jobId });
      }

      const newest = Math.max(0, (job.matchesCount || 0) - LIVE_ROWS);
      const page = await api('GET', `/api/discover/jobs/${encodeURIComponent(jobId)}/results?limit=${LIVE_ROWS}&offset=${newest}`);
      if (mine !== state.pollToken) return;
      state.results = page.results || [];
      renderJob();
    } catch (err) {
      if (mine !== state.pollToken) return;
      if (err.status === 401 || err.status === 402) { await handleAuthError(err); return; }
      if (err.status === 404) {
        await chrome.storage.local.remove(['activeJobId', 'finishedJobId']);
        newSearch();
        showFormError('That search is no longer available. Start a new one.');
        return;
      }
      failures += 1;
      setNote('Reconnecting…', true);
      if (failures >= 30) { showJobError("Lost contact with Sift. Your search keeps running — reopen this window in a minute."); return; }
    }
    await sleep(POLL_MS);
  }
}

async function attach(job) {
  showView('job');
  state.job = job;
  state.results = [];
  renderJob();
  renderAccess();

  if (FINISHED.includes(job.status)) { await onFinished(job); return; }

  // Still "pending" = the map lookup hasn't been handed to the server yet. The background worker normally has it;
  // this makes sure (it ignores the request if it already does).
  if (job.status === 'pending') send({ type: 'RESUME_PENDING', jobId: job.id });
  await chrome.storage.local.set({ activeJobId: job.id });
  send({ type: 'JOB_SEEN' });
  watchJob(job.id);
}

async function handleAuthError(err) {
  if (err.status === 401) await send({ type: 'SESSION_EXPIRED' });
  await refreshAccess(true);
}

async function startSearch() {
  if (state.starting) return;
  const form = readForm();
  if (!form) return;

  state.starting = true;
  $('#start').disabled = true;
  $('#start').textContent = 'Starting…';
  saveForm();

  try {
    // The background worker creates the search, then asks the map services from this computer and starts it —
    // so it all carries on if this window is closed.
    const res = await send({ type: 'START_SEARCH', body: form });
    if (!res) throw new ApiError('network', "Can't reach the extension's background worker. Reload the extension at chrome://extensions and try again.", 0);
    if (!res.ok) {
      const data = res.data || {};
      if (data.error === 'job_in_progress' && data.job) { await attach(data.job); return; } // already running — show it
      throw new ApiError(data.error || `http_${res.status}`, data.message || friendlyHttp(res.status), res.status, data);
    }
    await attach(res.data.job);
  } catch (err) {
    if (err.status === 401 || err.status === 402) await handleAuthError(err);
    else showFormError(err.message);
  } finally {
    state.starting = false;
    $('#start').textContent = 'Find businesses';
    renderAccess();
  }
}

async function cancelSearch() {
  const job = state.job;
  if (!job) return;
  $('#cancel').disabled = true;
  try {
    const res = await api('PATCH', `/api/discover/jobs/${encodeURIComponent(job.id)}`, { body: { status: 'cancelled' } });
    await onFinished(res.job);
  } catch (err) {
    showJobError(err.message);
  } finally {
    $('#cancel').disabled = false;
  }
}

function newSearch() {
  state.pollToken++;
  state.job = null;
  state.results = [];
  setGauge(0);
  showJobError('');
  showView('form');
  renderAccess();
  loadRecent();
}

/* ---------------- recent searches ---------------- */

const STATUS_LABEL = { pending: 'starting', running: 'running', completed: 'done', failed: 'failed', cancelled: 'cancelled' };

async function loadRecent() {
  const section = $('#recent');
  if (!state.status || state.status.plan === 'signed_out') { section.hidden = true; return; }
  try {
    const { jobs } = await api('GET', '/api/discover/jobs?limit=3');
    const list = $('#recentList');
    list.replaceChildren();
    for (const job of jobs || []) {
      const item = el('button', 'recent-item');
      item.type = 'button';
      const where = job.parsedFilters && job.parsedFilters.region ? ` · ${job.parsedFilters.region}` : '';
      item.append(
        el('span', 'q', `${job.rawQuery}${where}`),
        el('span', 'm', `${job.matchesCount || 0} found · ${STATUS_LABEL[job.status] || job.status} · ${timeAgo(job.createdAt)}`)
      );
      item.addEventListener('click', () => attach(job));
      list.appendChild(item);
    }
    section.hidden = !(jobs && jobs.length);
  } catch {
    section.hidden = true;
  }
}

/* ---------------- copy and export ---------------- */

function copyEmails() {
  const emails = [...new Set(state.results.map(r => r.email).filter(Boolean))];
  if (!emails.length) return;
  navigator.clipboard.writeText(emails.join('\n')).then(() => {
    const button = $('#copyEmails');
    button.textContent = `Copied ${emails.length}`;
    setTimeout(() => { button.textContent = 'Copy emails'; }, 1400);
  });
}

async function exportCsv() {
  const job = state.job;
  if (!job) return;
  const button = $('#csv');
  button.disabled = true;
  button.textContent = 'Exporting…';
  showJobError('');
  try {
    const blob = await api('GET', `/api/discover/jobs/${encodeURIComponent(job.id)}/export`, { blob: true });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sift-discovery-${slug(job.rawQuery)}-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  } catch (err) {
    if (err.status === 401) await handleAuthError(err);
    else showJobError(`Export failed: ${err.message}`);
  } finally {
    button.textContent = 'Export CSV';
    button.disabled = !state.results.length;
  }
}

/* ---------------- start-up ---------------- */

async function resumeIfAny() {
  if (!state.status || state.status.plan === 'signed_out') return;
  const { activeJobId, finishedJobId } = await chrome.storage.local.get(['activeJobId', 'finishedJobId']);
  const id = activeJobId || finishedJobId;
  if (!id) return;
  try {
    const { job } = await api('GET', `/api/discover/jobs/${encodeURIComponent(id)}`);
    await attach(job);
  } catch (err) {
    if (err.status === 404) await chrome.storage.local.remove(['activeJobId', 'finishedJobId']);
  }
}

function wireEvents() {
  $('#start').addEventListener('click', startSearch);
  $('#cancel').addEventListener('click', cancelSearch);
  $('#copyEmails').addEventListener('click', copyEmails);
  $('#csv').addEventListener('click', exportCsv);
  $('#again').addEventListener('click', newSearch);

  $('#gateAction').addEventListener('click', () => send({ type: 'OPEN_PROFILE' }));
  $('#bannerAction').addEventListener('click', () => send({ type: 'OPEN_PROFILE' }));
  $('#planMonthly').addEventListener('click', () => send({ type: 'OPEN_CHECKOUT', plan: 'monthly' }));
  $('#planYearly').addEventListener('click', () => send({ type: 'OPEN_CHECKOUT', plan: 'yearly' }));
  $('#gateEnterprise').addEventListener('click', e => { e.preventDefault(); send({ type: 'OPEN_ENTERPRISE' }); });
  $('#moreSift').addEventListener('click', e => { e.preventDefault(); send({ type: 'OPEN_SITE', path: '#products' }); });
  $('#account').addEventListener('click', e => { e.preventDefault(); send({ type: 'OPEN_PROFILE' }); });

  for (const id of ['#query', '#region', '#volume']) {
    $(id).addEventListener('input', () => { $(id).classList.remove('bad'); showFormError(''); if (id === '#volume') syncVolumeChips(); saveForm(); });
    $(id).addEventListener('keydown', e => { if (e.key === 'Enter') startSearch(); });
  }
  document.querySelectorAll('#must .chip').forEach(chip => {
    chip.addEventListener('click', () => { chip.setAttribute('aria-pressed', String(!pressed(chip))); saveForm(); });
  });

  // Whoever grants access (the Sift website's profile page, checkout) lives in
  // another tab, so re-check the moment this popup is shown again.
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshAccess(true); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') window.close(); });
  window.addEventListener('unload', () => { state.pollToken++; });

  // keep "N min left" honest while the window stays open
  setInterval(renderAccess, 30 * 1000);
}

async function boot() {
  buildGauge();
  setGauge(0);
  buildVolumeChips();
  await restoreForm();
  wireEvents();
  // Always ask for fresh status when the popup opens: someone who has just
  // finished their ads on the website must not see a stale "locked" screen.
  await refreshAccess(true);
  await resumeIfAny();
  if (!state.job) loadRecent();
  if (!$('#frame').classList.contains('locked')) $('#query').focus();
}

boot();
